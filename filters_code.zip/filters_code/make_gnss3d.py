"""Flagship 3D demo B: GNSS / PNT positioning.
A moving receiver estimates its 3D position (and its clock bias) from noisy
PSEUDORANGES to several satellites. A pseudorange is |p - s_i| + c*dt_clock + noise
-- nonlinear in position -- so again an EKF. State = [x,y,z, vx,vy,vz, b].
Work in kilometres; pseudorange noise 5 m. Local ENU frame, receiver near origin."""
import os, numpy as np
from _pal import *
from mpl_toolkits.mplot3d import Axes3D  # noqa
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(8)

Rorb=26600.0     # km, GPS orbit radius
# 7 satellites spread across the sky (azimuth, elevation)
az=np.deg2rad([20,75,140,200,255,300,350.]); el=np.deg2rad([70,35,55,25,60,40,30.])
sats=Rorb*np.c_[np.cos(el)*np.cos(az),np.cos(el)*np.sin(az),np.sin(el)]
M=len(sats)
srng=0.005       # 5 m pseudorange noise (km)

dt=1.0; N=50
# truth receiver: a drone moving a few hundred metres, with a drifting clock bias
pt=np.array([0.0,0.0,0.10]); vt=np.array([0.012,0.009,0.002])  # km/step (~12 m/s)
b=0.030          # clock bias in km (c*dt), drifts
truth=[]; bs=[]
for k in range(N):
    truth.append(np.r_[pt,vt]); bs.append(b)
    pt=pt+vt*dt + rng.normal(0,0.002,3)
    vt=vt+rng.normal(0,0.0008,3)
    b=b+0.0006+rng.normal(0,0.0003)     # clock drift
truth=np.array(truth); bs=np.array(bs)

def pseudorange(p,bb): return np.linalg.norm(p-sats,axis=1)+bb
Z=np.array([pseudorange(truth[k,:3],bs[k])+rng.normal(0,srng,M) for k in range(N)])

# --- EKF ---  state [x,y,z, vx,vy,vz, b, bdot]: clock bias AND drift, as real GNSS filters do
F=np.eye(8)
for i in range(3): F[i,i+3]=dt
F[6,7]=dt
Q=np.diag([1e-6,1e-6,1e-6, 4e-6,4e-6,4e-6, 1e-8,1e-8])
R=srng**2*np.eye(M)
xh=np.r_[truth[0,:3]+rng.normal(0,0.05,3), 0,0,0, 0.0,0.0]   # init: 50 m off, zero clock
P=np.diag([0.01,0.01,0.01, 1e-4,1e-4,1e-4, 0.01,1e-4])
est=[]; bES=[]; hdop=[]
for k in range(N):
    xh=F@xh; P=F@P@F.T+Q
    p=xh[:3]; bb=xh[6]
    yhat=np.linalg.norm(p-sats,axis=1)+bb
    los=(p-sats)/np.linalg.norm(p-sats,axis=1)[:,None]
    H=np.zeros((M,8)); H[:,:3]=los; H[:,6]=1.0
    S=H@P@H.T+R; K=P@H.T@np.linalg.inv(S)
    xh=xh+K@(Z[k]-yhat); P=(np.eye(8)-K@H)@P
    est.append(xh.copy()); bES.append(xh[6])
    G=np.c_[los,np.ones(M)]; Qg=np.linalg.inv(G.T@G); hdop.append(np.sqrt(Qg[0,0]+Qg[1,1]))
est=np.array(est); bES=np.array(bES)
perr=np.linalg.norm((truth[:,:3]-est[:,:3]),axis=1)*1000  # m
print("final pos err=%.1f m   mean (after convergence)=%.1f m   clock err=%.1f m"
      %(perr[-1],perr[8:].mean(),abs(bES[-1]-bs[-1])*1000))

fig=plt.figure(figsize=(12.6,4.2))
ax=fig.add_subplot(1,3,1,projection="3d")
ax.scatter(sats[:,0],sats[:,1],sats[:,2],color=ACC,s=45,marker="o",label="satellites")
for s in sats: ax.plot([0,s[0]],[0,s[1]],[0,s[2]],color=LINE,lw=0.6)
ax.scatter([0],[0],[0],color=RED,s=55,marker="^",label="receiver")
ax.set_title("(a) satellite geometry",fontsize=9.8); ax.legend(fontsize=7.4,frameon=False)
ax.set_xlabel("E (km)",fontsize=7.5); ax.set_ylabel("N (km)",fontsize=7.5); ax.set_zlabel("U (km)",fontsize=7.5)
ax.tick_params(labelsize=6); ax.view_init(elev=24,azim=-60)

b2=fig.add_subplot(1,3,2)
b2.plot(perr,color=ACC,lw=2)
b2.axhline(5,color=GREEN,lw=1,ls=":",label="5 m pseudorange noise")
b2.set_title("(b) 3D position error (metre-level)",fontsize=10,loc="left")
b2.set_xlabel("time step"); b2.set_ylabel("position error (m)"); b2.legend(fontsize=7.8,frameon=False); style(b2)

c=fig.add_subplot(1,3,3)
c.plot(bs*1000,color=INK,lw=2,label="true clock bias")
c.plot(bES*1000,color=ORANGE,lw=2,ls="--",label="EKF estimate")
c.set_title("(c) clock bias tracked too",fontsize=10,loc="left")
c.set_xlabel("time step"); c.set_ylabel("clock bias  $c\\,\\delta t$  (m)")
c.legend(fontsize=7.8,frameon=False); style(c)

fig.suptitle("3D GNSS/PNT: an EKF solves position AND receiver-clock bias from pseudoranges to several satellites",
             fontsize=11.0,y=1.02)
fig.tight_layout(); fig.savefig(os.path.join(OUT,"fig_gnss3d.png"),dpi=140,bbox_inches="tight")
with open(os.path.join(OUT,"nums_gnss.txt"),"w") as f:
    f.write("M=%d err_m=%.1f clock_m=%.1f hdop=%.2f\n"%(M,perr[8:].mean(),abs(bES[-1]-bs[-1])*1000,np.mean(hdop[8:])))
print("wrote fig_gnss3d.png")
