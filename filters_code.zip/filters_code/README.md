# Filters: from pen and paper to 3D — figure & note source

These scripts generate every figure in the note *Filters: from pen and paper to 3D*
(https://dipakmunshi87.github.io/ML_Stat_Notes/filters.html). Each figure is a small,
self-contained Python script; the note HTML is assembled from the figures, with all
mathematics pre-rendered to static SVG (so it displays with JavaScript disabled).

## Requirements

- Python 3.10+ with `numpy`, `scipy`, `matplotlib`:
  ```
  pip install numpy scipy matplotlib
  ```
- Node.js with `mathjax-full` (for the maths pre-renderer):
  ```
  npm install mathjax-full
  ```
- `_pal.py` holds the shared colour palette / matplotlib defaults used by every figure.

## Figure scripts (each writes a PNG into the current folder)

| script            | figure                                                        |
|-------------------|---------------------------------------------------------------|
| `make_cycle.py`   | the predict&ndash;update recursion loop                       |
| `make_1d_kf.py`   | the 1D scalar Kalman filter, worked by hand                   |
| `make_2d_cv.py`   | 2D constant-velocity tracking (position in, velocity out)     |
| `make_ekf.py`     | EKF linearization of a nonlinear measurement                  |
| `make_ukf.py`     | the unscented transform vs linearization                      |
| `make_pf.py`      | the particle filter on a bimodal posterior                    |
| `make_family.py`  | the filter family tree                                        |
| `make_radar3d.py` | **3D radar tracking** from range/azimuth/elevation (EKF/UKF)  |
| `make_gnss3d.py`  | **3D GNSS/PNT** positioning + clock bias from pseudoranges    |
| `make_enkf3d.py`  | **3D data assimilation** with the EnKF on Lorenz-63           |
| `make_tuning.py`  | the effect of mis-tuning the process noise Q                  |
| `make_preview.py` | the 1200x630 social preview card                              |

## Building the note

1. Run the figure scripts (any subset you want to regenerate).
2. `python build_filters_note.py` &mdash; embeds the figures (base64) and assembles the
   single scrolling note `filters_note.html`.
3. `node prerender_math.js filters_note.html filters_note.html` &mdash; replaces all
   `$...$`, `$$...$$`, `\(...\)`, `\[...\]` with static SVG.
4. `python build_filters_deck.py` &mdash; the paged (slide-deck) version `filters_deck.html`.

The three flagship demos are self-contained, tweakable Kalman/EKF/UKF/EnKF
implementations in plain NumPy &mdash; a good starting point for your own tracking,
navigation or assimilation problem. Larger runs use the Imperial College Research
Computing Service.

&mdash; Dr. Dipak Munshi, Advanced Research Fellow, Imperial College London
