"""EKF = linearize. Push a Gaussian in x through a nonlinear measurement h(x)=x^2.
The EKF replaces h by its tangent at the mean (slope H=2*mu), so it turns the
input Gaussian into another Gaussian. Compare that to the TRUE pushed density
(Monte-Carlo) to see the linearization error / bias."""
import os, numpy as np
from _pal import *
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(1)

mu,sig=1.3,0.55
h=lambda x:x**2
H=2*mu                       # Jacobian dh/dx at the mean
ymu_lin=h(mu); yvar_lin=H**2*sig**2    # EKF-linearized output Gaussian
# true pushed moments (chi-square-like): mean = mu^2+sig^2
samp=rng.normal(mu,sig,200000); ys=h(samp)
ytrue_mu,ytrue_sd=ys.mean(),ys.std()
print("EKF-linear: y~N(%.3f, %.3f^2)   true: mean=%.3f sd=%.3f (bias=%.3f)"
      %(ymu_lin,np.sqrt(yvar_lin),ytrue_mu,ytrue_sd,ytrue_mu-ymu_lin))

fig=plt.figure(figsize=(8.0,6.0)); fig.patch.set_facecolor("white")
gs=fig.add_gridspec(2,2,width_ratios=[1,3],height_ratios=[3,1],wspace=0.05,hspace=0.05)
axm=fig.add_subplot(gs[0,1]); axl=fig.add_subplot(gs[0,0],sharey=axm); axb=fig.add_subplot(gs[1,1],sharex=axm)
fig.add_subplot(gs[1,0]).axis("off")

xx=np.linspace(-0.4,3.0,400)
axm.plot(xx,h(xx),color=INK,lw=2.4,label="true $h(x)=x^2$")
axm.plot(xx,ymu_lin+H*(xx-mu),color=ACC,lw=2,ls="--",label="EKF tangent at $\\mu$")
axm.plot(mu,ymu_lin,"o",color=ACC,ms=7)
axm.set_ylim(-0.3,7.2); axm.set_xlim(-0.4,3.0)
axm.tick_params(labelbottom=False,labelleft=False); style(axm)
axm.legend(fontsize=8.4,frameon=False,loc="upper left")
axm.annotate("slope = $H=2\\mu$",(mu,ymu_lin),textcoords="offset points",xytext=(16,-20),
             fontsize=8.6,color=ACC2)

# bottom: input Gaussian p(x)
px=np.exp(-(xx-mu)**2/(2*sig**2))/np.sqrt(2*np.pi*sig**2)
axb.fill_between(xx,px,color=ORANGE,alpha=0.3); axb.plot(xx,px,color=ORANGE,lw=1.8)
axb.invert_yaxis(); axb.set_yticks([]); axb.set_xlabel("state  $x$   (prior Gaussian)")
axb.text(mu,0.1,"$p(x)=N(\\mu,\\sigma^2)$",fontsize=8.4,color="#b5791f",ha="center"); style(axb)

# left: output densities
yy=np.linspace(-0.3,7.2,400)
plin=np.exp(-(yy-ymu_lin)**2/(2*yvar_lin))/np.sqrt(2*np.pi*yvar_lin)
axl.plot(plin,yy,color=ACC,lw=2,label="EKF (Gaussian)")
axl.hist(ys,bins=120,range=(-0.3,7.2),density=True,orientation="horizontal",
         color=GREEN,alpha=0.35)
axl.plot([],[],color=GREEN,lw=6,alpha=0.35,label="true pushed")
axl.axhline(ymu_lin,color=ACC,lw=0.8,ls=":"); axl.axhline(ytrue_mu,color=GREEN,lw=0.9,ls=":")
axl.set_xlim(0,1.0); axl.invert_xaxis(); axl.set_xticks([]); axl.set_ylabel("measurement  $y=h(x)$")
axl.legend(fontsize=7.6,frameon=False,loc="upper right"); style(axl)
axl.annotate("bias:\ntrue mean\n$=\\mu^2+\\sigma^2$",(0.5,ytrue_mu),fontsize=7.6,color="#3f7a38",ha="center")

fig.suptitle("EKF in 1D: replace $h$ by its tangent, so a Gaussian stays Gaussian — "
             "accurate only when the curve is near-straight over $\\pm\\sigma$",fontsize=10.6,y=0.99)
fig.savefig(os.path.join(OUT,"fig_ekf.png"),dpi=140,bbox_inches="tight"); print("wrote fig_ekf.png")
with open(os.path.join(OUT,"nums_ekf.txt"),"w") as f:
    f.write("mu=%.2f sig=%.2f H=%.2f ylin=%.2f ytrue=%.3f bias=%.3f\n"%(mu,sig,H,ymu_lin,ytrue_mu,ytrue_mu-ymu_lin))
