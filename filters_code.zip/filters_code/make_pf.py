"""The particle filter, where Gaussians fail. Measurement z = x^2 + noise makes
the sign of x unobservable, so the posterior is genuinely BIMODAL. A Kalman/EKF
keeps one Gaussian bump (wrong); particles represent both peaks.
Three stages shown: (1) prior particles, (2) weight by likelihood, (3) resample."""
import os, numpy as np
from _pal import *
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(11)

# a static illustration at one step
Np=400
xp=rng.normal(0,1.6,Np)                 # prior particles (broad, centred 0)
ztrue=1.4**2                            # true state x=+/-1.4, we observe x^2
R=0.25
w=np.exp(-(ztrue-xp**2)**2/(2*R)); w/=w.sum()   # likelihood weights
# resample (systematic)
idx=np.searchsorted(np.cumsum(w),(rng.random()+np.arange(Np))/Np)
xr=xp[idx]

grid=np.linspace(-4,4,400)
post=np.zeros_like(grid)                # kernel estimate of weighted posterior
for xi,wi in zip(xp,w): post+=wi*np.exp(-(grid-xi)**2/(2*0.09))
post/=np.trapezoid(post,grid)
# what a single Gaussian (EKF-style) would report: mean & var of weighted particles
gm=np.sum(w*xp); gv=np.sum(w*(xp-gm)**2)
gauss=np.exp(-(grid-gm)**2/(2*gv))/np.sqrt(2*np.pi*gv)

fig,ax=plt.subplots(1,3,figsize=(12.4,3.6))
# (1) prior particles
ax[0].scatter(xp,rng.uniform(0,1,Np),s=10,color=MUT,alpha=0.35,edgecolors="none")
ax[0].set_title("(1) prior particles",fontsize=10,loc="left")
ax[0].set_yticks([]); ax[0].set_xlabel("state $x$"); style(ax[0]); ax[0].set_xlim(-4,4)
# (2) weighted by likelihood
sc=ax[1].scatter(xp,rng.uniform(0,1,Np),s=8+w/w.max()*120,color=ACC,alpha=0.5,edgecolors="none")
for xv in (-np.sqrt(ztrue),np.sqrt(ztrue)):
    ax[1].axvline(xv,color=GREEN,lw=1.2,ls=":")
ax[1].set_title("(2) weight by $p(z\\mid x)$, $z=x^2$",fontsize=10,loc="left")
ax[1].set_yticks([]); ax[1].set_xlabel("state $x$  (size = weight)"); style(ax[1]); ax[1].set_xlim(-4,4)
ax[1].text(0,1.02,"two values of $x$ explain $z$ → two peaks",ha="center",fontsize=8,color="#3f7a38")
# (3) resampled cloud + densities
ax[2].fill_between(grid,post,color=PURP,alpha=0.3,label="particle posterior")
ax[2].plot(grid,post,color=PURP,lw=2)
ax[2].plot(grid,gauss,color=RED,lw=2,ls="--",label="single Gaussian (wrong)")
ax[2].set_title("(3) resample → bimodal posterior",fontsize=10,loc="left")
ax[2].set_yticks([]); ax[2].set_xlabel("state $x$"); ax[2].set_xlim(-4,4)
ax[2].legend(fontsize=7.8,frameon=False); style(ax[2])

fig.suptitle("Particle filter: many weighted samples represent ANY posterior — here a bimodal one a Gaussian cannot",
             fontsize=11.0,y=1.02)
fig.tight_layout(); fig.savefig(os.path.join(OUT,"fig_pf.png"),dpi=140,bbox_inches="tight")
print("wrote fig_pf.png  ESS=%.0f  gauss mean=%.2f (true peaks at +/-%.2f)"
      %(1/np.sum(w**2),gm,np.sqrt(ztrue)))
