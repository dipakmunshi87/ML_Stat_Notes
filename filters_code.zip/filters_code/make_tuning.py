"""The practical catch: the filter is only as good as its noise settings Q and R.
A target cruises then suddenly manoeuvres. Three 1D filters:
 - Q too small: 'trusts the model', ignores the new data, LAGS and its +/-sigma band
   no longer contains the truth (overconfident -> inconsistent -> can diverge).
 - Q right: tracks the manoeuvre, band covers the truth.
 - Q too big: 'trusts the data', follows the measurement noise (jittery)."""
import os, numpy as np
from _pal import *
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(6)

N=60; R=4.0
# truth: constant, then a ramp (manoeuvre) from k=30
x=np.zeros(N)
for k in range(1,N):
    x[k]=x[k-1]+(0.0 if k<30 else 0.9)
z=x+rng.normal(0,np.sqrt(R),N)

def run(Q):
    xh=np.zeros(N); P=np.zeros(N); xh[0]=z[0]; P[0]=R
    for k in range(1,N):
        xp=xh[k-1]; Pp=P[k-1]+Q
        K=Pp/(Pp+R); xh[k]=xp+K*(z[k]-xp); P[k]=(1-K)*Pp
    return xh,np.sqrt(P)

t=np.arange(N)
xs,ss=run(0.001)        # too small
xm,sm=run(0.25)         # about right
xb,sb=run(8.0)          # too big

fig,(a1,a2)=plt.subplots(1,2,figsize=(11.6,4.2))
a1.plot(t,z,"o",color=ORANGE,ms=3,alpha=0.5,label="measurements")
a1.plot(t,x,color=INK,lw=2,label="truth (manoeuvre at k=30)")
a1.plot(t,xs,color=RED,lw=1.8,label="Q too small (lags)")
a1.plot(t,xm,color=GREEN,lw=1.8,label="Q right")
a1.plot(t,xb,color=PURP,lw=1.2,alpha=0.8,label="Q too big (jittery)")
a1.axvline(30,color=MUT,lw=0.8,ls=":")
a1.set_title("(a) same data, three Q settings",fontsize=10,loc="left")
a1.set_xlabel("time step"); a1.set_ylabel("state"); a1.legend(fontsize=7.6,frameon=False); style(a1)

# consistency: does truth stay inside the +/-2sigma band?
a2.fill_between(t,xs-2*ss,xs+2*ss,color=RED,alpha=0.18,label="Q too small: $\\pm2\\sigma$")
a2.fill_between(t,xm-2*sm,xm+2*sm,color=GREEN,alpha=0.18,label="Q right: $\\pm2\\sigma$")
a2.plot(t,x,color=INK,lw=2,label="truth")
a2.plot(t,xs,color=RED,lw=1.4); a2.plot(t,xm,color=GREEN,lw=1.4)
a2.axvline(30,color=MUT,lw=0.8,ls=":")
a2.annotate("truth leaves the\nred band → overconfident",(40,x[40]),textcoords="offset points",
            xytext=(-120,-6),fontsize=8,color="#b24a40",
            arrowprops=dict(arrowstyle="->",color="#b24a40",lw=1))
a2.set_title("(b) is the filter honest about its error?",fontsize=10,loc="left")
a2.set_xlabel("time step"); a2.set_ylabel("state"); a2.legend(fontsize=7.4,frameon=False,loc="upper left"); style(a2)

fig.suptitle("Tuning matters: too small a Q makes the filter overconfident and it diverges; too big and it just echoes the noise",
             fontsize=10.6,y=1.0)
fig.tight_layout(); fig.savefig(os.path.join(OUT,"fig_tuning.png"),dpi=140,bbox_inches="tight")
print("wrote fig_tuning.png")
