"""1200x630 OpenGraph preview card for the Filters note."""
import os, numpy as np
from _pal import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
OUT=os.path.dirname(os.path.abspath(__file__))
fig=plt.figure(figsize=(12,6.3),dpi=100); fig.patch.set_facecolor("#ffffff")
ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,12); ax.set_ylim(0,6.3); ax.axis("off")
ax.set_facecolor("white")
for sp in ax.spines.values(): sp.set_visible(False)
ax.grid(False)
# left accent bar
ax.add_patch(plt.Rectangle((0,0),0.22,6.3,color=ACC))
ax.text(0.7,5.4,"A reproducible technical note",fontsize=15,color=MUT)
ax.text(0.68,4.25,"Filters",fontsize=60,color=ACC2,fontweight="bold")
ax.text(0.72,3.35,"from pen and paper to 3D",fontsize=27,color=INK)
ax.text(0.72,2.5,"Predict, then correct — the Kalman, extended, unscented and",fontsize=15.5,color=INK)
ax.text(0.72,2.08,"particle filters, from a scalar by hand to radar tracking,",fontsize=15.5,color=INK)
ax.text(0.72,1.66,"GNSS positioning and data assimilation.",fontsize=15.5,color=INK)
ax.text(0.72,0.72,"Dr. Dipak Munshi  ·  ML & Statistics Notes",fontsize=15,color=ACC2,fontweight="bold")

# small predict->update motif on the right
def box(x,w,c,fc,lab):
    ax.add_patch(FancyBboxPatch((x,4.0),w,1.0,boxstyle="round,pad=0.02,rounding_size=0.08",
        lw=1.8,edgecolor=c,facecolor=fc))
    ax.text(x+w/2,4.5,lab,ha="center",va="center",fontsize=12.5,color=c,fontweight="bold")
box(8.5,1.55,ACC2,"#eef4fb","predict")
box(10.3,1.55,GREEN,"#eefaef","update")
ax.add_patch(FancyArrowPatch((10.05,4.68),(10.3,4.68),arrowstyle="-|>",mutation_scale=13,lw=1.6,color=MUT))
ax.add_patch(FancyArrowPatch((10.3,4.32),(10.05,4.32),arrowstyle="-|>",mutation_scale=13,lw=1.6,color=MUT))
ax.text(9.9,3.5,"grow, then shrink the uncertainty",ha="center",fontsize=11,color=ACC2,style="italic")
fig.savefig(os.path.join(OUT,"filters_preview.png"),dpi=100); print("wrote filters_preview.png")
