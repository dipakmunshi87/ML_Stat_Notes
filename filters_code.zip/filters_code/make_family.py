"""The family tree: one general Bayesian filter, four practical members, each
defined by the approximation it makes to keep the recursion tractable."""
import os, numpy as np
from _pal import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
OUT=os.path.dirname(os.path.abspath(__file__))
fig,ax=plt.subplots(figsize=(11.2,5.0)); ax.set_xlim(0,11.2); ax.set_ylim(0,5.0); ax.axis("off")

def box(cx,cy,w,h,title,body,c,fc,tsz=11,bsz=8.2):
    ax.add_patch(FancyBboxPatch((cx-w/2,cy-h/2),w,h,boxstyle="round,pad=0.03,rounding_size=0.1",
        lw=1.8,edgecolor=c,facecolor=fc))
    ax.text(cx,cy+h/2-0.26,title,ha="center",va="center",fontsize=tsz,color=c,fontweight="bold")
    ax.text(cx,cy-0.12,body,ha="center",va="center",fontsize=bsz,color=INK)

# top: general filter
box(5.6,4.4,6.2,1.0,"General Bayesian filter",
    "$p(x_k\\mid z_{1:k})\\;\\propto\\;p(z_k\\mid x_k)\\int p(x_k\\mid x_{k-1})\\,p(x_{k-1}\\mid z_{1:k-1})\\,dx_{k-1}$",
    INK,"#f6f8fb",tsz=12,bsz=9)

ys=1.5; w=2.35; h=1.55
box(1.6,ys,w,h,"Kalman","linear dynamics,\nGaussian noise.\nExact & closed-form.",ACC2,"#eef4fb")
box(4.45,ys,w,h,"EKF","nonlinear, but\nlinearize (Jacobian)\nat the mean.",ACC,"#eef4fb")
box(7.3,ys,w,h,"UKF","nonlinear: push\nsigma points through\ng( ) — no Jacobian.",TEAL,"#e9f7f5")
box(10.0,ys,w,h,"Particle filter","any density: many\nweighted samples\n+ resampling.",PURP,"#f3eff8")

for cx,lab in [(1.6,"linear +\nGaussian"),(4.45,"linearize"),(7.3,"unscented\ntransform"),(10.0,"sample")]:
    ax.add_patch(FancyArrowPatch((5.6,3.9),(cx,ys+h/2),arrowstyle="-|>",mutation_scale=13,lw=1.5,color=MUT,
        connectionstyle="arc3,rad=0.0"))
    mx=5.6+0.62*(cx-5.6); my=3.9+0.62*((ys+h/2)-3.9)
    ax.text(mx,my,lab,ha="center",va="center",fontsize=7.4,color=MUT,style="italic",
            bbox=dict(boxstyle="round,pad=0.12",fc="white",ec="none"))

ax.text(5.6,0.28,"left → right: fewer assumptions, more general, more compute.  "
        "Pick the simplest one your problem allows.",
        ha="center",fontsize=8.8,color=MUT,style="italic")
fig.suptitle("One recursion, four filters — each is the general Bayesian filter plus one approximation",
             fontsize=11.6,y=1.0)
fig.savefig(os.path.join(OUT,"fig_family.png"),dpi=140,bbox_inches="tight"); print("wrote fig_family.png")
