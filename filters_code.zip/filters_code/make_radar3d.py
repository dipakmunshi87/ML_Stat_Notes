"""Flagship 3D demo A: radar target tracking.
A target flies in 3D (constant-velocity with a slow turn). A radar at the origin
measures range, azimuth, elevation -- all NONLINEAR in the Cartesian state, so we
need EKF or UKF. State = [x,y,z,vx,vy,vz]. We compare EKF vs UKF: 3D tracks,
position RMSE over time, and filter consistency (NEES)."""
import os, numpy as np
from _pal import *
from mpl_toolkits.mplot3d import Axes3D  # noqa
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(4)

dt=1.0; N=60
F=np.eye(6);
for i in range(3): F[i,i+3]=dt
q=0.25
Gm=np.zeros((6,3));
for i in range(3): Gm[i,i]=dt**2/2; Gm[i+3,i]=dt
Q=Gm@(q*np.eye(3))@Gm.T
# measurement noise: range (m), az, el (rad). Coarse angles + a near-overhead
# pass make the range/az/el map strongly nonlinear -- the regime where UKF wins.
sr,sa,se=12.0,np.deg2rad(1.4),np.deg2rad(1.4)
R=np.diag([sr**2,sa**2,se**2])

def h(s):
    x,y,z=s[0],s[1],s[2]; rho=np.sqrt(x*x+y*y+z*z); rh=np.sqrt(x*x+y*y)
    return np.array([rho, np.arctan2(y,x), np.arctan2(z,rh)])
def Hjac(s):
    x,y,z=s[0],s[1],s[2]; rho2=x*x+y*y+z*z; rho=np.sqrt(rho2); rh=np.sqrt(x*x+y*y)
    J=np.zeros((3,6))
    J[0,0]=x/rho; J[0,1]=y/rho; J[0,2]=z/rho
    J[1,0]=-y/(x*x+y*y); J[1,1]=x/(x*x+y*y)
    J[2,0]=-x*z/(rho2*rh); J[2,1]=-y*z/(rho2*rh); J[2,2]=rh/rho2
    return J
def wrap(a): return (a+np.pi)%(2*np.pi)-np.pi
def meas2cart(zz):
    rho,az,el=zz
    return np.array([rho*np.cos(el)*np.cos(az), rho*np.cos(el)*np.sin(az), rho*np.sin(el)])

# --- truth: fly in and pass almost overhead the radar (closest approach ~60 m),
# so azimuth and elevation swing fast through the pass ---
s=np.array([560.,470.,300., -18.5, -15.5, -7.2])
truth=[]
for k in range(N):
    truth.append(s.copy())
    turn=np.array([0.4*np.sin(k/12), 0.35*np.cos(k/9), 0.1])  # mild unmodelled accel
    s=F@s + np.r_[0,0,0,turn]*dt
truth=np.array(truth)
Z=np.array([h(t)+rng.multivariate_normal(np.zeros(3),R) for t in truth])

def run(kind):
    xh=np.r_[meas2cart(Z[0]), 0,0,0.0]          # init from the first measurement
    P=np.diag([400.,400,400, 900,900,900.])
    est=[]; nees=[]
    for k in range(N):
        xh=F@xh; P=F@P@F.T+Q
        if kind=="ekf":
            Hk=Hjac(xh); yhat=h(xh)
            S=Hk@P@Hk.T+R; K=P@Hk.T@np.linalg.inv(S)
            innov=Z[k]-yhat; innov[1]=wrap(innov[1]); innov[2]=wrap(innov[2])
            xh=xh+K@innov; P=(np.eye(6)-K@Hk)@P
        else:  # ukf
            n=6; kappa=3-n
            Lc=np.linalg.cholesky((n+kappa)*P)
            sp=[xh]+[xh+Lc[:,i] for i in range(n)]+[xh-Lc[:,i] for i in range(n)]
            wm=np.full(2*n+1,1/(2*(n+kappa))); wm[0]=kappa/(n+kappa); wc=wm
            Y=np.array([h(p) for p in sp])
            # unwrap angles relative to first sigma pt for safe averaging
            for j in (1,2): Y[:,j]=Y[0,j]+wrap(Y[:,j]-Y[0,j])
            yhat=(wm[:,None]*Y).sum(0)
            Pyy=sum(wc[i]*np.outer(Y[i]-yhat,Y[i]-yhat) for i in range(2*n+1))+R
            Pxy=sum(wc[i]*np.outer(sp[i]-xh,Y[i]-yhat) for i in range(2*n+1))
            K=Pxy@np.linalg.inv(Pyy)
            innov=Z[k]-yhat; innov[1]=wrap(innov[1]); innov[2]=wrap(innov[2])
            xh=xh+K@innov; P=P-K@Pyy@K.T
        est.append(xh.copy())
        e=truth[k,:3]-xh[:3]; nees.append(e@np.linalg.inv(P[:3,:3])@e)
    return np.array(est),np.array(nees)

ekf,nee_e=run("ekf"); ukf,nee_u=run("ukf")
raw=np.array([meas2cart(z) for z in Z])                 # measurements as raw 3D points
rmse_e=np.linalg.norm(truth[:,:3]-ekf[:,:3],axis=1)
rmse_u=np.linalg.norm(truth[:,:3]-ukf[:,:3],axis=1)
rmse_raw=np.linalg.norm(truth[:,:3]-raw,axis=1)
print("mean pos RMSE  raw=%.1f m  EKF=%.1f m  UKF=%.1f m"
      %(rmse_raw[3:].mean(),rmse_e[3:].mean(),rmse_u[3:].mean()))

fig=plt.figure(figsize=(12.6,4.2))
ax=fig.add_subplot(1,3,1,projection="3d")
ax.scatter(raw[:,0],raw[:,1],raw[:,2],color=ORANGE,s=12,alpha=0.5,label="raw measurements")
ax.plot(truth[:,0],truth[:,1],truth[:,2],color=INK,lw=2,label="true path")
ax.plot(ukf[:,0],ukf[:,1],ukf[:,2],color=TEAL,lw=1.8,label="UKF track")
ax.scatter([0],[0],[0],color=RED,s=40,marker="^"); ax.text(0,0,0,"  radar",color=RED,fontsize=8)
ax.set_title("(a) raw points vs filtered track",fontsize=9.6); ax.legend(fontsize=6.8,frameon=False,loc="upper left")
ax.set_xlabel("x (m)",fontsize=8); ax.set_ylabel("y (m)",fontsize=8); ax.set_zlabel("z (m)",fontsize=8)
ax.tick_params(labelsize=6.5); ax.view_init(elev=22,azim=-58)

b=fig.add_subplot(1,3,2)
b.plot(rmse_raw,color=ORANGE,lw=1.6,alpha=0.8,label="raw measurements")
b.plot(rmse_e,color=ACC,lw=1.8,ls="--",label="EKF")
b.plot(rmse_u,color=TEAL,lw=2,label="UKF")
b.set_title("(b) position error: filter vs raw",fontsize=10,loc="left")
b.set_xlabel("time step"); b.set_ylabel("position RMSE (m)"); b.legend(fontsize=8,frameon=False); style(b)

c=fig.add_subplot(1,3,3)
c.plot(nee_e,color=ACC,lw=1.2,ls="--",label="EKF NEES"); c.plot(nee_u,color=TEAL,lw=1.5,label="UKF NEES")
c.axhspan(0.35,9.35,color=GREEN,alpha=0.12)   # approx 95% band for chi2_3
c.axhline(3,color=GREEN,lw=1,ls=":",label="E[NEES]=3")
c.set_title("(c) consistency (NEES, 3 dof)",fontsize=10,loc="left")
c.set_xlabel("time step"); c.set_ylabel("NEES"); c.set_ylim(0,20); c.legend(fontsize=7.4,frameon=False); style(c)

fig.suptitle("3D radar tracking: a nonlinear filter turns noisy range/azimuth/elevation into a clean 3D track",
             fontsize=11.2,y=1.02)
fig.tight_layout(); fig.savefig(os.path.join(OUT,"fig_radar3d.png"),dpi=140,bbox_inches="tight")
with open(os.path.join(OUT,"nums_radar.txt"),"w") as f:
    f.write("rmse_raw=%.1f rmse_ekf=%.1f rmse_ukf=%.1f sr=%.0f sa_deg=%.1f\n"
            %(rmse_raw[3:].mean(),rmse_e[3:].mean(),rmse_u[3:].mean(),sr,np.rad2deg(sa)))
print("wrote fig_radar3d.png")
