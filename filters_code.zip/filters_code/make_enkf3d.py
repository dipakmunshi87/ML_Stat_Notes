"""Flagship 3D demo C: data assimilation with the Ensemble Kalman Filter (EnKF).
The state is the 3D Lorenz-63 system (x,y,z) -- chaotic, so a free run from a
slightly wrong start diverges completely. We observe (x,y,z) noisily every few
steps and assimilate with an ensemble of 40 members. The EnKF keeps the estimate
locked to the truth; the free run (no data) wanders off the attractor's other wing.
This is how weather and ocean models stay on track."""
import os, numpy as np
from _pal import *
from mpl_toolkits.mplot3d import Axes3D  # noqa
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(2)

sigma,rho,beta=10.0,28.0,8/3
def f(s):
    x,y,z=s
    return np.array([sigma*(y-x), x*(rho-z)-y, x*y-beta*z])
def rk4(s,dt):
    k1=f(s); k2=f(s+dt/2*k1); k3=f(s+dt/2*k2); k4=f(s+dt*k3)
    return s+dt/6*(k1+2*k2+2*k3+k4)

dt=0.01; T=1800; obs_every=20
s=np.array([1.0,1.0,1.0])
for _ in range(2000): s=rk4(s,dt)          # spin up onto the attractor
truth=np.zeros((T,3));
for k in range(T): truth[k]=s; s=rk4(s,dt)

Rstd=2.0; R=Rstd**2*np.eye(3)
obs_t=np.arange(0,T,obs_every)
obs={k: truth[k]+rng.normal(0,Rstd,3) for k in obs_every*np.arange(1,T//obs_every)}

# --- EnKF (stochastic / perturbed-obs) ---
m=40; infl=1.02
ens=truth[0]+rng.normal(0,5,(m,3))
mean_en=np.zeros((T,3)); spread=np.zeros(T)
# --- free run (ensemble mean start, no assimilation) ---
free=ens.mean(0).copy(); freerec=np.zeros((T,3))
for k in range(T):
    if k>0:
        for i in range(m): ens[i]=rk4(ens[i],dt)
        free=rk4(free,dt)
    freerec[k]=free
    if k in obs:
        xbar=ens.mean(0); A=ens-xbar
        A*=infl; ens=xbar+A                      # covariance inflation
        Pf=(A.T@A)/(m-1)
        S=Pf+R; K=Pf@np.linalg.inv(S)            # H = I (observe all 3)
        for i in range(m):
            yp=obs[k]+rng.normal(0,Rstd,3)       # perturbed observation
            ens[i]=ens[i]+K@(yp-ens[i])
    mean_en[k]=ens.mean(0); spread[k]=np.sqrt(((ens-ens.mean(0))**2).sum(1).mean())

rmse_en=np.linalg.norm(mean_en-truth,axis=1)
rmse_free=np.linalg.norm(freerec-truth,axis=1)
tt=np.arange(T)*dt
print("EnKF RMSE (steady) = %.2f   free-run RMSE (late) = %.2f"
      %(rmse_en[T//3:].mean(),rmse_free[T//2:].mean()))

fig=plt.figure(figsize=(12.6,4.2))
ax=fig.add_subplot(1,3,1,projection="3d")
ax.plot(truth[:,0],truth[:,1],truth[:,2],color=INK,lw=0.7,alpha=0.8,label="truth")
ax.plot(mean_en[:,0],mean_en[:,1],mean_en[:,2],color=GREEN,lw=0.9,alpha=0.9,label="EnKF mean")
ax.set_title("(a) Lorenz-63 attractor: EnKF stays on truth",fontsize=9.2)
ax.legend(fontsize=7.2,frameon=False)
ax.set_xlabel("x",fontsize=8); ax.set_ylabel("y",fontsize=8); ax.set_zlabel("z",fontsize=8)
ax.tick_params(labelsize=6); ax.view_init(elev=24,azim=-62)

b=fig.add_subplot(1,3,2)
b.fill_between(tt,mean_en[:,0]-spread,mean_en[:,0]+spread,color=GREEN,alpha=0.2,label="ensemble $\\pm$ spread")
b.plot(tt,truth[:,0],color=INK,lw=1.4,label="truth $x(t)$")
b.plot(tt,mean_en[:,0],color=GREEN,lw=1.4,label="EnKF mean")
b.plot(tt,freerec[:,0],color=RED,lw=1.1,ls="--",alpha=0.8,label="free run (no data)")
ot=np.array(sorted(obs)); b.plot(ot*dt,[obs[k][0] for k in ot],"o",color=ORANGE,ms=2.6,alpha=0.6,label="obs")
b.set_title("(b) the $x$ component in time",fontsize=10,loc="left")
b.set_xlabel("time"); b.set_ylabel("$x$"); b.legend(fontsize=6.6,frameon=False,ncol=2,loc="lower center"); style(b)

c=fig.add_subplot(1,3,3)
c.plot(tt,rmse_free,color=RED,lw=1.4,ls="--",label="free run")
c.plot(tt,rmse_en,color=GREEN,lw=1.6,label="EnKF")
c.axhline(Rstd,color=MUT,lw=1,ls=":",label="obs noise")
c.set_title("(c) error: data keeps it on track",fontsize=10,loc="left")
c.set_xlabel("time"); c.set_ylabel("state RMSE"); c.legend(fontsize=7.4,frameon=False); style(c)

fig.suptitle("Ensemble Kalman filter on 3D Lorenz-63: 40 members + noisy data tame a chaotic system (how weather models work)",
             fontsize=10.6,y=1.02)
fig.tight_layout(); fig.savefig(os.path.join(OUT,"fig_enkf3d.png"),dpi=140,bbox_inches="tight")
with open(os.path.join(OUT,"nums_enkf.txt"),"w") as f:
    f.write("m=%d rmse_enkf=%.2f rmse_free=%.1f obsstd=%.1f\n"
            %(m,rmse_en[T//3:].mean(),rmse_free[T//2:].mean(),Rstd))
print("wrote fig_enkf3d.png")
