"""2D constant-velocity tracking. State x=[px,py,vx,vy]; we measure position only,
noisily. Shows the true path, the measurements, the filtered track, and 2-sigma
covariance ellipses (big after predict, small after update) at a few steps."""
import os, numpy as np
from _pal import *
from matplotlib.patches import Ellipse
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(3)

dt=1.0
F=np.array([[1,0,dt,0],[0,1,0,dt],[0,0,1,0],[0,0,0,1.0]])
H=np.array([[1,0,0,0],[0,1,0,0.0]])
q=0.12; R=np.diag([4.0,4.0])          # noisy position sensor (sigma=2)
G=np.array([[dt**2/2,0],[0,dt**2/2],[dt,0],[0,dt]])
Q=G@ (q*np.eye(2)) @G.T
N=30
# truth: curved path (gentle acceleration) so CV model is slightly wrong -> realistic
x=np.array([0,0,1.0,1.2]); truth=[]
for k in range(N):
    truth.append(x.copy())
    a=np.array([0,0,0.04*np.cos(k/5),-0.06])   # small unmodelled accel
    x=F@x + np.r_[0,0,a[2],a[3]]
truth=np.array(truth)
meas=truth[:,:2]+rng.normal(0,2.0,size=(N,2))

# filter -- initialise position and velocity from the first two measurements
v0=(meas[1]-meas[0])/dt
xh=np.array([meas[0,0],meas[0,1],v0[0],v0[1]]); P=np.diag([4,4,9,9.0])
est=[]; covs=[]
for k in range(N):
    # predict
    xh=F@xh; P=F@P@F.T+Q
    Ppred=P.copy()
    # update
    S=H@P@H.T+R; K=P@H.T@np.linalg.inv(S)
    xh=xh+K@(meas[k]-H@xh); P=(np.eye(4)-K@H)@P
    est.append(xh.copy()); covs.append((Ppred[:2,:2],P[:2,:2]))
est=np.array(est)

def ell(ax,mean,cov,c,ls="-",a=0.0,lw=1.6,z=3):
    w,v=np.linalg.eigh(cov); ang=np.degrees(np.arctan2(v[1,-1],v[0,-1]))
    e=Ellipse(mean,2*2*np.sqrt(w[-1]),2*2*np.sqrt(w[0]),angle=ang,fill=(a>0),
              facecolor=c,alpha=a,edgecolor=c,lw=lw,ls=ls,zorder=z)
    ax.add_patch(e)

fig,ax=plt.subplots(figsize=(7.8,5.8))
ax.plot(meas[:,0],meas[:,1],"o",color=ORANGE,ms=5,alpha=0.55,label="measurements (position only)",zorder=2)
ax.plot(truth[:,0],truth[:,1],color=INK,lw=2,label="true path",zorder=4)
ax.plot(est[:,0],est[:,1],color=ACC,lw=2,marker=".",ms=6,label="Kalman track",zorder=5)
for k in [4,12,20,27]:
    ell(ax,est[k,:2],covs[k][1],GREEN,a=0.28,z=3)          # posterior 2-sigma
ax.plot([],[],color=GREEN,lw=6,alpha=0.4,label="posterior 2$\\sigma$ (position)")
# velocity arrows: the filter infers velocity it never measured
for k in [6,14,22]:
    ax.annotate("",xy=(est[k,0]+est[k,2]*2.2,est[k,1]+est[k,3]*2.2),xytext=(est[k,0],est[k,1]),
                arrowprops=dict(arrowstyle="-|>",color=PURP,lw=1.8))
ax.plot([],[],color=PURP,lw=1.8,label="inferred velocity (never measured)")
ax.set_xlabel("x position"); ax.set_ylabel("y position"); ax.set_aspect("equal")
ax.legend(fontsize=8,frameon=False,loc="lower right"); style(ax)
ax.set_title("2D tracking: position-only measurements in → a smooth track and the velocity you never measured out",
             fontsize=9.6,loc="left")
fig.tight_layout(); fig.savefig(os.path.join(OUT,"fig_2d_cv.png"),dpi=140,bbox_inches="tight")
print("wrote fig_2d_cv.png  final pos err=%.2f"%np.hypot(*(est[-1,:2]-truth[-1,:2])))
