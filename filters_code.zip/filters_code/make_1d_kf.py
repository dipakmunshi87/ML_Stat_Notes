"""1D scalar Kalman filter, worked by hand.
State: a slowly drifting scalar (random-walk model x_k = x_{k-1} + w, w~N(0,Q)).
Measure: z_k = x_k + v, v~N(0,R). Three panels:
 (a) the run: truth, noisy measurements, estimate +/- sigma
 (b) one step as three bell curves: prior -> predicted (wider) -> posterior (narrower)
 (c) the gain K_k and variance P_k settling to their steady state.
Prints the first few steps' numbers so the note can quote them."""
import os, numpy as np
from _pal import *
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(7)

Q=0.01       # process-noise variance (how much the truth can drift per step)
R=0.25       # measurement-noise variance (how noisy the sensor is)
N=40
# --- simulate truth + measurements ---
x=np.zeros(N); x[0]=1.0
for k in range(1,N): x[k]=x[k-1]+rng.normal(0,np.sqrt(Q))
z=x+rng.normal(0,np.sqrt(R),size=N)

# --- run the filter ---
xh=np.zeros(N); P=np.zeros(N); K=np.zeros(N)
xh[0]=z[0]; P[0]=R
rec=[]
for k in range(1,N):
    xp=xh[k-1]          # predict mean (random walk: unchanged)
    Pp=P[k-1]+Q         # predict variance (grows by Q)
    Kk=Pp/(Pp+R)        # Kalman gain
    xh[k]=xp+Kk*(z[k]-xp)   # update mean
    P[k]=(1-Kk)*Pp          # update variance
    K[k]=Kk
    if k<=4: rec.append((k,xp,Pp,Kk,z[k],xh[k],P[k]))

print("step  x^-   P^-    K     z     x^+   P^+")
for r in rec: print("%2d  %.3f %.3f %.3f %.3f %.3f %.3f"%r)
Pss=P[-1]; Kss=K[-1]
print("steady-state P=%.4f  K=%.4f"%(Pss,Kss))

fig=plt.figure(figsize=(12.4,3.5));
gs=fig.add_gridspec(1,3,width_ratios=[1.5,1.05,1.0],wspace=0.28)
a=fig.add_subplot(gs[0,0]); b=fig.add_subplot(gs[0,1]); c=fig.add_subplot(gs[0,2])

# (a) the run
t=np.arange(N)
a.fill_between(t,xh-np.sqrt(P),xh+np.sqrt(P),color=ACC,alpha=0.18,label="estimate $\\pm\\sigma$")
a.plot(t,x,color=INK,lw=2,label="true state")
a.plot(t,z,"o",color=ORANGE,ms=4,alpha=0.7,label="measurements")
a.plot(t,xh,color=ACC,lw=2,label="filter estimate")
a.set_title("(a) the filter run",loc="left"); a.set_xlabel("time step $k$"); a.set_ylabel("value")
a.legend(fontsize=7.4,frameon=False,loc="lower right"); style(a)

# (b) one step: three bells
xs=np.linspace(-1.2,1.8,400)
def g(m,v): return np.exp(-(xs-m)**2/(2*v))/np.sqrt(2*np.pi*v)
m0,v0=0.55,0.06                 # posterior from last step (prior for this one)
mp,vp=m0,v0+Q                   # predicted (wider)
zmeas=0.95
Kk=vp/(vp+R); mu=mp+Kk*(zmeas-mp); vpost=(1-Kk)*vp
b.plot(xs,g(m0,v0),color=MUT,lw=1.6,ls="--",label="prior (last post.)")
b.plot(xs,g(mp,vp),color=ACC,lw=2,label="predicted (wider +Q)")
b.axvline(zmeas,color=ORANGE,lw=1.6,ls=":",label="measurement $z$")
b.plot(xs,g(mu,vpost),color=GREEN,lw=2.4,label="posterior (narrower)")
b.set_title("(b) one predict–update step",loc="left"); b.set_xlabel("state $x$"); b.set_yticks([])
b.legend(fontsize=7.0,frameon=False,loc="upper left"); style(b)

# (c) gain & variance settling
c.plot(t[1:],K[1:],color=PURP,lw=2,marker="o",ms=3,label="gain $K_k$")
c.plot(t[1:],P[1:],color=RED,lw=2,marker="s",ms=3,label="variance $P_k$")
c.axhline(Kss,color=PURP,lw=0.8,ls=":"); c.axhline(Pss,color=RED,lw=0.8,ls=":")
c.set_title("(c) gain & variance settle",loc="left"); c.set_xlabel("time step $k$")
c.legend(fontsize=7.6,frameon=False); style(c)

fig.suptitle("The 1D Kalman filter: predict widens the Gaussian (+Q), update narrows it toward the measurement",
             fontsize=11.3,y=1.02)
fig.savefig(os.path.join(OUT,"fig_1d_kf.png"),dpi=140,bbox_inches="tight"); print("wrote fig_1d_kf.png")

# save numbers for the note
with open(os.path.join(OUT,"nums_kf.txt"),"w") as f:
    f.write("Q=%.2f R=%.2f Pss=%.3f Kss=%.3f\n"%(Q,R,Pss,Kss))
    for (k,xp,Pp,Kk2,zz,xp2,Pp2) in rec:
        f.write("k%d xpred=%.3f Ppred=%.3f K=%.3f z=%.3f xpost=%.3f Ppost=%.3f\n"%(k,xp,Pp,Kk2,zz,xp2,Pp2))
