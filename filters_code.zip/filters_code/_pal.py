"""Shared palette + matplotlib defaults for the filters note figures."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ACC="#3D7EBF"; ACC2="#245a95"; RED="#D9675C"; GREEN="#5BA552"
INK="#1c2530"; MUT="#5b6b7a"; LINE="#e3e8ee"; ORANGE="#E0922F"; PURP="#8E6FB0"; TEAL="#2BA9A0"
plt.rcParams.update({
    "font.size":10, "axes.edgecolor":"#cfd6de", "axes.labelcolor":INK,
    "xtick.color":MUT, "ytick.color":MUT, "text.color":INK,
    "axes.titlesize":10.5, "figure.facecolor":"white", "axes.facecolor":"white",
    "axes.grid":True, "grid.color":"#eef2f6", "grid.linewidth":0.8,
})
def style(ax):
    for sp in ax.spines.values(): sp.set_color("#cfd6de")
    ax.set_axisbelow(True)
