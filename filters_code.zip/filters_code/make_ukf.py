"""The unscented transform (the heart of the UKF). Instead of linearizing, pick a
small set of deterministic 'sigma points' that capture the mean and covariance,
push each through the nonlinear map, and read off the output mean/covariance.
Here the map is polar->Cartesian g(r,theta)=(r cos th, r sin th) with a large
bearing spread, the case where EKF linearization is notoriously bad."""
import os, numpy as np
from _pal import *
from matplotlib.patches import Ellipse
OUT=os.path.dirname(os.path.abspath(__file__))
rng=np.random.default_rng(5)

mean=np.array([4.0, 0.9])            # [range, bearing(rad)]
cov=np.diag([0.25, 0.5**2])          # big bearing uncertainty (0.5 rad)
g=lambda s: np.array([s[0]*np.cos(s[1]), s[0]*np.sin(s[1])])

# --- sigma points (n=2): 2n+1=5 points ---
n=2; kappa=1.0
L=np.linalg.cholesky((n+kappa)*cov)
sp=[mean]+[mean+L[:,i] for i in range(n)]+[mean-L[:,i] for i in range(n)]
sp=np.array(sp)
wm=np.full(2*n+1,1/(2*(n+kappa))); wm[0]=kappa/(n+kappa); wc=wm.copy()
Y=np.array([g(s) for s in sp])
ymean=(wm[:,None]*Y).sum(0)
ycov=sum(wc[i]*np.outer(Y[i]-ymean,Y[i]-ymean) for i in range(2*n+1))

# --- EKF linearization for comparison ---
r,th=mean; J=np.array([[np.cos(th),-r*np.sin(th)],[np.sin(th),r*np.cos(th)]])
ekf_mean=g(mean); ekf_cov=J@cov@J.T

# --- Monte-Carlo truth ---
S=rng.multivariate_normal(mean,cov,4000); MC=np.array([g(s) for s in S])

def ell(ax,m,C,c,ls="-",lab=None,lw=2):
    w,v=np.linalg.eigh(C); ang=np.degrees(np.arctan2(v[1,-1],v[0,-1]))
    ax.add_patch(Ellipse(m,2*2*np.sqrt(w[-1]),2*2*np.sqrt(w[0]),angle=ang,fill=False,
        edgecolor=c,lw=lw,ls=ls,label=lab))

fig,(a1,a2)=plt.subplots(1,2,figsize=(11.0,4.6))
# input space
Sin=rng.multivariate_normal(mean,cov,1500)
a1.scatter(Sin[:,0],Sin[:,1],s=4,color=MUT,alpha=0.18,edgecolors="none")
a1.scatter(sp[:,0],sp[:,1],s=90,color=TEAL,edgecolors="k",zorder=5,label="sigma points")
a1.plot(mean[0],mean[1],"o",color=ACC2,ms=8,zorder=6,label="mean")
a1.set_xlabel("range $r$"); a1.set_ylabel("bearing $\\theta$ (rad)")
a1.set_title("(a) input: a few sigma points carry mean+cov",fontsize=10,loc="left")
a1.legend(fontsize=8,frameon=False); style(a1)

# output space
a2.scatter(MC[:,0],MC[:,1],s=4,color=GREEN,alpha=0.14,edgecolors="none")
a2.plot([],[],color=GREEN,lw=6,alpha=0.3,label="true (Monte-Carlo)")
a2.scatter(Y[:,0],Y[:,1],s=90,color=TEAL,edgecolors="k",zorder=5,label="pushed sigma points")
ell(a2,ymean,ycov,TEAL,lab="UKF mean/cov",lw=2.4)
ell(a2,ekf_mean,ekf_cov,ACC,ls="--",lab="EKF (linearized)")
a2.plot(ymean[0],ymean[1],"o",color=TEAL,ms=7,zorder=6)
a2.plot(ekf_mean[0],ekf_mean[1],"s",color=ACC,ms=7,zorder=6)
a2.set_xlabel("x"); a2.set_ylabel("y"); a2.set_aspect("equal")
a2.set_title("(b) output: UKF tracks the banana; EKF misses it",fontsize=10,loc="left")
a2.legend(fontsize=8,frameon=False,loc="lower left"); style(a2)

fig.suptitle("The unscented transform: push sigma points through $g$ (no Jacobian) and recover the moments",
             fontsize=11.2,y=1.0)
fig.tight_layout(); fig.savefig(os.path.join(OUT,"fig_ukf.png"),dpi=140,bbox_inches="tight")
print("wrote fig_ukf.png  UKF mean=(%.2f,%.2f)  EKF mean=(%.2f,%.2f)  true mean=(%.2f,%.2f)"
      %(ymean[0],ymean[1],ekf_mean[0],ekf_mean[1],MC[:,0].mean(),MC[:,1].mean()))
