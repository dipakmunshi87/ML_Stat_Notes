"""The Bayesian filtering recursion as a two-box loop: Predict (move forward with
the dynamics, uncertainty grows) and Update (fold in the measurement, uncertainty
shrinks). This single picture underlies every filter in the note."""
import os, numpy as np
from _pal import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
OUT=os.path.dirname(os.path.abspath(__file__))
fig,ax=plt.subplots(figsize=(10.2,3.9)); ax.set_xlim(0,10.2); ax.set_ylim(0,3.9); ax.axis("off")

def box(x,y,w,h,title,body,c,fc):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.03,rounding_size=0.12",
        lw=2,edgecolor=c,facecolor=fc))
    ax.text(x+w/2,y+h-0.33,title,ha="center",va="center",fontsize=13,color=c,fontweight="bold")
    ax.text(x+w/2,y+h/2-0.28,body,ha="center",va="center",fontsize=9.6,color=INK)

box(0.7,1.2,3.6,1.9,"PREDICT",
    "move with the dynamics\n$\\hat{x}^-=F\\hat{x}$\n$P^-=FPF^{\\top}+Q$\n(uncertainty grows)",ACC2,"#eef4fb")
box(5.9,1.2,3.6,1.9,"UPDATE",
    "fold in the measurement\n$K=P^-H^{\\top}(HP^-H^{\\top}+R)^{-1}$\n$\\hat{x}=\\hat{x}^-+K(z-H\\hat{x}^-)$\n(uncertainty shrinks)",GREEN,"#eefaef")

# arrows between them (a loop)
ax.add_patch(FancyArrowPatch((4.3,2.55),(5.9,2.55),arrowstyle="-|>",mutation_scale=18,lw=2,color=MUT))
ax.text(5.1,2.78,"prior $\\hat{x}^-,P^-$",ha="center",fontsize=8.6,color=MUT)
ax.add_patch(FancyArrowPatch((5.9,1.75),(4.3,1.75),arrowstyle="-|>",mutation_scale=18,lw=2,color=MUT,
    connectionstyle="arc3,rad=0"))
ax.text(5.1,1.5,"posterior $\\hat{x},P$  (next step's prior)",ha="center",fontsize=8.6,color=MUT)

# measurement feeding update
ax.add_patch(FancyArrowPatch((7.7,3.55),(7.7,3.12),arrowstyle="-|>",mutation_scale=16,lw=1.8,color=ORANGE))
ax.text(7.7,3.72,"measurement $z_k$",ha="center",fontsize=9,color="#b5791f",fontweight="bold")
# clock tick at the bottom
ax.add_patch(FancyArrowPatch((2.5,1.2),(2.5,0.55),arrowstyle="-|>",mutation_scale=14,lw=1.4,color=MUT))
ax.add_patch(FancyArrowPatch((2.5,0.55),(7.7,0.55),arrowstyle="-",lw=1.4,color=MUT,ls=":"))
ax.add_patch(FancyArrowPatch((7.7,0.55),(7.7,1.2),arrowstyle="-|>",mutation_scale=14,lw=1.4,color=MUT,ls=":"))
ax.text(5.1,0.33,"advance one time step  $k\\!\\to\\!k\\!+\\!1$",ha="center",fontsize=8.4,color=MUT,style="italic")

ax.text(5.1,3.75,"",ha="center")
fig.suptitle("The filtering recursion: alternate PREDICT (grow uncertainty) and UPDATE (shrink it with data)",
             fontsize=11.4,y=1.0)
fig.savefig(os.path.join(OUT,"fig_cycle.png"),dpi=140,bbox_inches="tight"); print("wrote fig_cycle.png")
