# Model card: `tiny_gpt`

**What it is.** A character-level, decoder-only transformer with 108k parameters (d = 64, 4 heads, 2 layers,
context 64), trained from scratch by `llmnote-tiny-gpt` on a five-sentence paragraph about the heat equation and
Black–Scholes, repeated 40 times (≈ 20k characters, vocabulary 29). AdamW, lr 3e-3, 600 steps, batch 32; about a
minute on a laptop CPU, seconds on a GPU.

**Intended use.** Teaching. It exists so that every line of a GPT — tokeniser, embeddings, causal attention,
residual blocks, next-token cross-entropy, sampling — can be read and run in one file. The loss curve it produces
is Figure 6 of the note.

**Performance.** Training loss falls from ln 29 ≈ 3.37 nats (random guessing) to ≈ 0.07 nats; the model memorises the
paragraph and reproduces it from a two-word prompt. It generalises to nothing: there is no held-out data, and none is
claimed. `tests/test_tiny_gpt.py` checks only that the loss falls by > 0.3 nats in 50 CPU steps.

**Limitations.** Not a language model of English; it has seen 29 characters and one paragraph. No post-training,
no safety behaviour, no evaluation beyond the training loss. Do not use it for anything except understanding the code.

**Data.** The training text is in `src/llmnote/tiny_gpt.py` (`TEXT`), written by the author; no external data.

**Compute and energy.** ≈ 10⁹ FLOPs per step × 600 steps ≈ 6×10¹¹ FLOPs — a few joules.
