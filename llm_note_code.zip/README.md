# llmnote — code for *Large Language Models: from Pen-and-Paper to Physics*

[![ci](https://github.com/dipakmunshi87/ML_Stat_Notes/actions/workflows/ci.yml/badge.svg)](https://github.com/dipakmunshi87/ML_Stat_Notes/actions/workflows/ci.yml)
![python](https://img.shields.io/badge/python-3.10%20|%203.11%20|%203.12-blue)
![license](https://img.shields.io/badge/license-MIT-green)

Runnable companions to the note
[**Large Language Models: from Pen-and-Paper to Physics**](https://dipakmunshi87.github.io/ML_Stat_Notes/llm_note.html)
(19 pages, 16 computed figures, worked examples, 20 Q&A), plus the build pipeline that produces the note itself.
Every number quoted in the note is produced by code in this directory with fixed seeds.

## Quickstart

```bash
git clone https://github.com/dipakmunshi87/ML_Stat_Notes.git && cd ML_Stat_Notes/code/llm_note
python -m venv .venv && source .venv/bin/activate
pip install torch --index-url https://download.pytorch.org/whl/cpu   # CPU torch (skip if you have CUDA torch)
pip install -e ".[dev]"
pytest -q                       # 14 tests, ~10 s on CPU
llmnote-bigram                  # the pen-and-paper language model of Chapter 1
```

## What each program does

| Command | Module | What it does | Expected output (abridged) |
|---|---|---|---|
| `llmnote-bigram` | `bigram.py` | Fits a bigram model to three sentences by counting; samples a sentence; scores a held-out one | `P(cat|the) = 0.333 … perplexity 1.67` |
| `llmnote-bpe` | `bpe.py` | Learns byte-pair merges on four words, printing the corpus after each merge; tokenises unseen words | `merge 1: e+s (count 9) … lowest -> ['low', 'est</w>']` |
| `llmnote-attention` | `attention_by_hand.py` | Attention on four temperature readings along a rod: scores, softmax weights, outputs; position-only vs content-aware keys | `weights for point 1: [0.575 0.337 0.078 0.011] -> 1.31 … hot spot kept` |
| `llmnote-tiny-gpt` | `tiny_gpt.py` | A complete GPT (108k parameters) trained on a paragraph; `--steps`, `--device` | `step 0 loss 3.49 … step 500 loss 0.07` then generated text |
| `llmnote-equations` | `solve_equations.py` | Chapter 11's equations by sympy (exact) and by numpy/scipy (`linalg.solve`, `quad`, `solve_ivp`), side by side | `int e^-x^2 [0,1] 0.746824132812 … exact 0.746824132812` |
| `llmnote-integrate` | `integrate_demo.py` | Midpoint, trapezoid, Simpson, Gauss–Legendre and Monte Carlo on ∫₀¹e^{-x²}dx; error-vs-N table; `--figure path.png` | table of errors; `Monte Carlo, 10000 samples: 0.74704 +- 0.00201` |
| `llmnote-rag` | `rag_minimal.py` | Embeds five sentences with MiniLM, retrieves top-2 by cosine, answers from them with a 0.5B instruct model (`--no-generate` for retrieval only) | `[4] score 0.72 … ANSWER: About twenty tokens per parameter [4].` |
| `llmnote-lora` | `lora_minimal.py` | LoRA (rank 8, q/v projections) fine-tune of a 0.5B open model with `peft`; GPU recommended (`--fp16` on pre-Ampere) | `trainable params: 540,672 … adapter saved to ./lora-out` |

The last two need `pip install -e ".[gpu]"` and download models from the Hugging Face Hub on first use.
`MODEL_CARD.md` describes the tiny GPT honestly (it memorises one paragraph; that is the point).

## How CI works

Every push to `main` and every pull request runs `.github/workflows/ci.yml` on GitHub's hosted Ubuntu runners: three
jobs, one per Python version (3.10, 3.11, 3.12), each on a fresh machine that installs CPU PyTorch and the package,
runs `ruff` and `pytest -q`, then executes the pen-and-paper examples and the integration demo and uploads their printed
outputs and the error-vs-N figure as downloadable artifacts. A red cross on a commit means a test or the linter failed
on a clean machine; a green tick means every number the note quotes from these scripts still reproduces. The test
suite is deliberately CPU-sized (the tiny GPT trains for 50 steps in a few seconds) so that CI costs nothing and finishes
in about three minutes.

## GPU runs

GitHub's free runners have **no GPU**, so `.github/workflows/gpu.yml` is a *manual* workflow (`workflow_dispatch`)
that runs on a **self-hosted runner** you register on a machine with an NVIDIA card — a workstation, or a cluster login
node that submits `scripts/run_gpu.pbs` to the queue. Registering a runner takes three commands on that machine
(the exact token comes from *Settings → Actions → Runners → New self-hosted runner* on GitHub):

```bash
mkdir actions-runner && cd actions-runner && curl -o r.tar.gz -L https://github.com/actions/runner/releases/latest/download/actions-runner-linux-x64.tar.gz && tar xzf r.tar.gz
./config.sh --url https://github.com/dipakmunshi87/ML_Stat_Notes --token <TOKEN> --labels gpu
./run.sh      # or ./svc.sh install && ./svc.sh start to run it as a service
```

Then *Actions → gpu → Run workflow*. Without a runner, the same job runs on Imperial CX3 with
`qsub scripts/run_gpu.pbs` (one L40S, ~10 minutes): it trains the tiny GPT on the GPU and does a 60-step LoRA
fine-tune of a 0.5B model.

## Docker and Make

```bash
make docker     # builds python:3.11-slim image with CPU torch, runs the tests and the examples
make test lint demo
```

## The note itself

`note/` holds the build pipeline: `compute_llm.py` (every figure and number, ~2 min CPU), `chapters/*.html`
(sources with `$...$` maths, `{{v:key}}` values, `{{fig:name|caption}}` figures), `make_code_chapter.py`,
`build.py` (assembles the paged reader and renders TeX → SVG server-side with `mathrender.js`), `template.html`,
`make_preview.py`. `make note` rebuilds `llm_note.html`; `npm install` in `note/` once for MathJax.

## Layout

```
code/llm_note/
├── src/llmnote/        bigram, bpe, attention_by_hand, tiny_gpt, lora_minimal, rag_minimal, solve_equations, integrate_demo
├── tests/              pytest: probabilities sum to one, BPE merge order, attention weights, tiny_gpt loss falls,
│                       sympy ↔ numerical agreement, quadrature convergence
├── scripts/run_gpu.pbs Imperial CX3 job for the GPU examples
├── .github/workflows/  ci.yml (CPU matrix, every push) · gpu.yml (manual, self-hosted GPU runner)
├── note/               the HTML note's build pipeline
├── Dockerfile · Makefile · pyproject.toml · MODEL_CARD.md
```

MIT licence. Dipak Munshi, 2026.
