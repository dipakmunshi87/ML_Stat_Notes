from llmnote import integrate_demo as q


def test_rules_converge():
    e4 = abs(q.simpson(q.F, 0, 1, 4) - q.EXACT); e8 = abs(q.simpson(q.F, 0, 1, 8) - q.EXACT)
    assert e8 < e4 / 10                       # ~N^-4
    t4 = abs(q.trapezoid(q.F, 0, 1, 4) - q.EXACT); t8 = abs(q.trapezoid(q.F, 0, 1, 8) - q.EXACT)
    assert 3 < t4 / t8 < 5                     # ~N^-2
    assert abs(q.gauss_legendre(q.F, 0, 1, 2) - q.EXACT) < 1e-3
    assert abs(q.gauss_legendre(q.F, 0, 1, 8) - q.EXACT) < 1e-12


def test_monte_carlo_error_bar():
    est, se = q.monte_carlo(q.F, 0, 1, 20000, seed=1)
    assert abs(est - q.EXACT) < 4 * se


def test_hand_values():
    assert abs(q.simpson(q.F, 0, 1, 4) - 0.746855) < 1e-6
    assert abs(q.gauss_legendre(q.F, 0, 1, 2) - 0.746595) < 1e-6
