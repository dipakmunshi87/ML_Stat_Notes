import numpy as np

from llmnote.attention_by_hand import attention, rod_example


def test_weights_sum_to_one_and_values():
    r = rod_example()
    assert np.allclose(r["W_pos"].sum(1), 1.0)
    assert np.allclose(r["W_content"].sum(1), 1.0)
    assert np.allclose(r["W_pos"][0], [0.575, 0.337, 0.078, 0.011], atol=2e-3)
    assert abs(r["y_pos"][0] - 1.31) < 0.01
    assert abs(r["y_content"][0] - 1.00) < 0.02     # cool point cleaned
    assert abs(r["y_content"][2] - 4.97) < 0.05     # hot spot kept


def test_softmax_invariance():
    Q = np.random.default_rng(0).normal(size=(3, 2))
    W1, _ = attention(Q, Q, np.ones(3), beta=1.0)
    W2, _ = attention(Q + 100.0, Q, np.ones(3), beta=1.0)   # shift of all scores in a row leaves softmax unchanged
    assert np.allclose(W1.sum(1), 1.0)
