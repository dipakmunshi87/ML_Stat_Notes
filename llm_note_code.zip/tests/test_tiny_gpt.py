import numpy as np
import torch

from llmnote import tiny_gpt


def test_loss_decreases_in_50_steps_on_cpu():
    torch.set_num_threads(2)
    model, losses, stoi, itos = tiny_gpt.train(steps=50, device="cpu", log_every=0)
    assert np.mean(losses[:5]) > np.mean(losses[-5:]) + 0.3
    assert sum(p.numel() for p in model.parameters()) > 50_000


def test_generate_runs():
    model, losses, stoi, itos = tiny_gpt.train(steps=2, device="cpu", log_every=0)
    s = tiny_gpt.generate(model, stoi, itos, "the", n=10)
    assert s.startswith("the") and len(s) == 13
