from llmnote import bpe


def test_merge_order_and_counts():
    merges = bpe.learn(n_merges=3)
    assert [m[0] for m in merges] == [("e", "s"), ("es", "t"), ("est", "</w>")]
    assert [m[1] for m in merges] == [9, 9, 9]


def test_tokenise_unseen_word():
    merges = bpe.learn(n_merges=8)
    assert bpe.tokenise("lowest", merges) == ["low", "est</w>"]
    assert "".join(bpe.tokenise("newer", merges)) == "newer</w>"
