import math

import sympy as sp

from llmnote import solve_equations as se


def test_symbolic():
    r = se.symbolic()
    assert r["linear"] == [5]
    assert sorted(r["quadratic_roots"]) == [2, 3]
    assert list(r["system"].values()) == [3, 2]
    assert r["linear_ode_check"][0] is True
    assert sp.simplify(r["heat_b1"] - 8 / sp.pi**2) == 0 and r["heat_b2"] == 0
    assert r["int_x2"] == sp.Rational(1, 3) and r["int_sin"] == 2


def test_numerical_matches_analytic():
    n = se.numerical()
    assert abs(n["system"][0] - 3) < 1e-12 and abs(n["system"][1] - 2) < 1e-12
    assert max(abs(n["system3"] - [2, 3, -1])) < 1e-10
    assert abs(n["int_x2"] - 1 / 3) < 1e-12 and abs(n["int_sin"] - 2) < 1e-12
    assert abs(n["int_gauss"] - math.sqrt(math.pi) / 2 * math.erf(1)) < 1e-10
    assert abs(n["decay_num_at_4"] - n["decay_exact_at_4"]) < 1e-8
    assert abs(n["linear_ode_num_at_3"] - n["linear_ode_exact_at_3"]) < 1e-8
    assert abs(n["sho_num_at_5"] - n["sho_exact_at_5"]) < 1e-7
