from llmnote import bigram


def test_rows_are_distributions():
    vocab, P = bigram.fit()
    ix = {w: i for i, w in enumerate(vocab)}
    sums = P.sum(1)
    for w in vocab:
        if w != "</s>":  # the end marker has no successors
            assert abs(sums[ix[w]] - 1.0) < 1e-12


def test_known_probabilities_and_perplexity():
    vocab, P = bigram.fit()
    ix = {w: i for i, w in enumerate(vocab)}
    assert abs(P[ix["the"], ix["cat"]] - 1 / 3) < 1e-12
    assert P[ix["sat"], ix["on"]] == 1.0
    ll, ce, ppl = bigram.score(vocab, P, "the dog sat on the mat")
    assert abs(ppl - 1.67) < 0.01
    assert ppl >= 1.0


def test_sample_ends():
    vocab, P = bigram.fit()
    s = bigram.generate(vocab, P, seed=1)
    assert all(w in vocab for w in s.split())
