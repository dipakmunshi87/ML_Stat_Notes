"""1200x630 social-preview image for the LLM note: an attention-weight field with a causal mask."""
import os, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.colors import LinearSegmentedColormap

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "llm_note_preview.png")
W, H = 12.0, 6.3; BG = "#0b1730"
fig = plt.figure(figsize=(W, H), dpi=100); fig.patch.set_facecolor(BG)
axbg = fig.add_axes([0, 0, 1, 1]); axbg.set_axis_off()
yy, xx = np.mgrid[0:int(H * 100), 0:int(W * 100)]
r = np.sqrt((xx - 0.74 * W * 100) ** 2 + (yy - 0.5 * H * 100) ** 2)
axbg.imshow(np.exp(-(r / 520) ** 2), cmap=LinearSegmentedColormap.from_list("g", [BG, "#13305c"]), extent=[0, W * 100, 0, H * 100], origin="lower", aspect="auto")
axbg.set_xlim(0, W * 100); axbg.set_ylim(0, H * 100)

# a structured causal attention matrix: previous-token diagonal, a few "attention sink" columns, a content band
rng = np.random.default_rng(4); n = 28
A = rng.gamma(0.6, 1.0, (n, n)) * 0.25
for i in range(n):
    A[i, i] += 2.2;
    if i > 0: A[i, i - 1] += 1.6
    if i > 1: A[i, i - 2] += 0.5
A[:, 0] += 1.4; A[:, 9] += 0.8 * (np.arange(n) > 9); A[:, 17] += 0.9 * (np.arange(n) > 17)
for i in range(n):
    for j in range(i):
        if (i - j) % 7 == 0: A[i, j] += 0.9
A[np.triu_indices(n, 1)] = np.nan
A = A / np.nanmax(A, axis=1, keepdims=True)
ax = fig.add_axes([0.50, 0.08, 0.47, 0.84]); ax.set_facecolor("none")
cmap = LinearSegmentedColormap.from_list("a", ["#0e2347", "#1f4f9a", "#35a9d8", "#5ee6c8", "#ffd166"])
ax.imshow(A, cmap=cmap, interpolation="nearest", aspect="equal")
ax.set_xticks([]); ax.set_yticks([])
for s in ax.spines.values(): s.set_edgecolor((1, 1, 1, 0.12))
ax.set_xlabel("attended token  (key)", color="#8fa6c8", fontsize=9.5, labelpad=6)
ax.set_ylabel("current token  (query)", color="#8fa6c8", fontsize=9.5, labelpad=6)
ax.text(0.5, 1.045, "a causal attention map", transform=ax.transAxes, color="#5ee6ff", fontsize=10.5, fontweight="bold", ha="center")
ax.text(0.5, 1.005, "each row is a learned kernel over the past; nothing above the diagonal", transform=ax.transAxes, color="#8fa6c8", fontsize=8.5, ha="center")
ax.text(0.60, 0.78, r"$\alpha_{ij}=\mathrm{softmax}_j\!\left(\mathbf{q}_i\!\cdot\!\mathbf{k}_j/\sqrt{d}\right)$", transform=ax.transAxes, color="#dbe6f5", fontsize=11)

axt = fig.add_axes([0, 0, 1, 1]); axt.set_axis_off(); axt.set_xlim(0, 1); axt.set_ylim(0, 1)
axt.add_patch(FancyBboxPatch((0.0, 0.0), 0.012, 1.0, boxstyle="square,pad=0", fc="#5ee6ff", ec="none", zorder=3))
axt.text(0.055, 0.87, "FROM PEN-AND-PAPER TO PHYSICS", color="#8fa6c8", fontsize=11, fontweight="bold", zorder=4)
axt.text(0.055, 0.72, "Large", color="#ffffff", fontsize=50, fontweight="bold", zorder=4)
axt.text(0.055, 0.585, "Language Models", color="#ffffff", fontsize=42, fontweight="bold", zorder=4)
axt.text(0.055, 0.49, "built from first principles, with every derivation", color="#dbe6f5", fontsize=16.5, zorder=4)
lines = ["Bigram model by hand · tokens & BPE · embeddings · RoPE",
         "Attention derived on a 1-D rod · the transformer · 6ND",
         "Cross-entropy & Adam · scaling laws · RLHF and DPO derived",
         "LoRA · RAG · solving equations · Boltzmann · Hopfield · fields & RFI"]
for i, s in enumerate(lines):
    axt.text(0.055, 0.395 - i * 0.058, s, color="#a9b8d0", fontsize=11.0, zorder=4)
axt.text(0.055, 0.105, "19 pages  ·  16 computed figures  ·  8 programs  ·  20 Q&A", color="#5ee6ff", fontsize=11, fontweight="bold", zorder=4)
axt.text(0.055, 0.05, "Dr Dipak Munshi  ·  ML & Statistics Notes", color="#ffffff", fontsize=11.5, fontweight="bold", zorder=4)
fig.savefig(OUT, dpi=100, facecolor=BG); print("saved", OUT)
