"""Generate chapters/14_code.html from scripts/*.py with light syntax highlighting (run before build.py)."""
import html, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.environ.get("LLMNOTE_SRC") or (os.path.join(HERE, "..", "src", "llmnote") if os.path.isdir(os.path.join(HERE, "..", "src", "llmnote")) else os.path.join(HERE, "scripts"))
KW = r"\b(import|from|def|class|return|for|while|if|elif|else|in|not|and|or|with|as|lambda|yield|break|continue|pass|True|False|None|print)\b"

def hl(code):
    out = []
    for line in code.rstrip("\n").split("\n"):
        esc = html.escape(line)
        # split off a trailing comment (a # not inside quotes)
        body, com = esc, ""
        depth_q = 0
        for i, ch in enumerate(esc):
            if esc.startswith("&quot;", i) or esc.startswith("&#x27;", i):
                depth_q ^= 1
            if ch == "#" and depth_q == 0:
                body, com = esc[:i], esc[i:]
                break
        # strings -> placeholders, keywords, restore strings
        strings = []
        def stash(mm):
            strings.append(mm.group(0)); return f"\x00{len(strings)-1}\x00"
        body = re.sub(r"(&quot;.*?&quot;|&#x27;.*?&#x27;)", stash, body)
        body = re.sub(KW, lambda mm: f'<span class="k">{mm.group(1)}</span>', body)
        body = re.sub(r'(<span class="k">def</span> )(\w+)', r'\1<span class="f">\2</span>', body)
        body = re.sub(r"\x00(\d+)\x00", lambda mm: f'<span class="s">{strings[int(mm.group(1))]}</span>', body)
        out.append(body + (f'<span class="c">{com}</span>' if com else ""))
    return "\n".join(out)

scripts = [
    ("bigram.py", "A bigram language model (Chapter 1)",
     "Counts transitions over three sentences, normalises rows into $P(w'\\mid w)$, samples a sentence from the table, and scores a held-out sentence: log-likelihood, cross-entropy per token and perplexity. Thirty lines of NumPy, and already a language model in the full sense of Chapter&nbsp;1.",
     "P(cat|the) = 0.333  P(on|sat) = 1.0 / sample: the mat / log-likelihood -3.584  cross-entropy 0.512 nats/token  perplexity 1.67"),
    ("bpe.py", "Byte-pair encoding from scratch (Chapter 2)",
     "Learns merges on the four-word corpus of Chapter&nbsp;2 by repeatedly counting symbol pairs and merging the most frequent one, printing the corpus after every merge, then tokenises two unseen words by replaying the merges in order. <em>lowest</em> becomes <code>low</code> + <code>est&lt;/w&gt;</code>.",
     "merge 1: e+s (count 9) -> ... / merge 8: new+est</w> (count 6) -> {'low </w>': 5, 'low e r </w>': 2, 'newest</w>': 6, 'w i d est</w>': 3} / lowest -> ['low', 'est</w>']   newer -> ['new', 'e', 'r', '</w>']"),
    ("attention_by_hand.py", "Attention on the hot rod (Chapter 4)",
     "The worked example of Chapter&nbsp;4 with every intermediate printed: scores, softmax weights and the new values, first with position-only keys (a smoothing kernel that smears the hot spot) and then with keys that carry the reading (cool points ignore the hot one, the hot point keeps its value). Twenty lines of NumPy; compare the numbers with the text.",
     "weights for point 1: [0.575 0.337 0.078 0.011] -> new value 1.31 / all new values: [1.311 2.015 2.735 2.346] / content-aware weights for point 1: [0.623 0.365 0.001 0.011] -> 1.0 / all new values: [1.002 1.008 4.969 1.012]"),
    ("tiny_gpt.py", "A complete GPT in 70 lines (Chapters 5&ndash;6)",
     "Character-level tokeniser, token and position embeddings, causal multi-head attention, pre-norm residual blocks with GELU MLPs, next-token cross-entropy, AdamW, and sampling &mdash; the whole decoder-only transformer, 108k parameters, training on a CPU in about a minute. Everything in a production model is this scaled up.",
     "step 0 loss 3.49 (random guess = 3.37) / step 500 loss 0.07 / parameters: 108 k, vocab 29 / the black scholes equation for an option price is the heat equation in disguise: ..."),
    ("solve_equations.py", "The equations of Chapter 11, by SymPy and by SciPy",
     "Every equation of Chapter&nbsp;11 solved twice: exactly with <code>sympy</code> (<code>solve</code>, <code>factor</code>, <code>dsolve</code> with initial conditions, <code>checkodesol</code>, symbolic integration giving $8/\\pi^2$ for the heat-equation coefficient) and numerically with <code>numpy.linalg.solve</code>, <code>scipy.integrate.quad</code> and <code>solve_ivp</code>, with the two routes printed side by side. This is the script a tool-using model writes instead of doing algebra in its head.",
     "linear [5] / quadratic_roots [2, 3] / linear_ode_check (True, 0) / heat_b1 8/pi**2 / int e^-x^2 [0,1] 0.746824132812 +- 8.3e-15 exact 0.746824132812 / SHO x(5) -0.8390715290 exact -0.8390715291"),
    ("integrate_demo.py", "Numerical integration from scratch (Chapter 11)",
     "Midpoint, trapezoid, Simpson, Gauss&ndash;Legendre and Monte Carlo rules written out in a few lines each, all applied to $\\int_0^1 e^{-x^2}\\,\\mathrm dx$, with the error against $N$ tabulated and plotted (Figure in Section 11.10): the $N^{-2}$, $N^{-4}$, exponential and $N^{-1/2}$ convergence rates are visible by eye.",
     "    4   1.92e-03   3.84e-03   3.12e-05   3.35e-07   2.59e-02 / … / Monte Carlo, 10000 samples: 0.74704 +- 0.00201 (exact 0.74682)"),
    ("lora_minimal.py", "LoRA fine-tuning of an open model (Chapter 9)",
     "Loads a 0.5B-parameter open model from the Hugging Face Hub, freezes it, attaches rank-8 adapters to the attention query and value matrices with <code>peft</code>, and fine-tunes on a text dataset with the standard <code>Trainer</code>. About 0.1% of the weights are trainable; the adapter saved at the end is a few megabytes. Needs a GPU for comfort (use <code>fp16</code> instead of <code>bf16</code> on pre-Ampere cards).",
     "trainable params: 540,672 || all params: 494,573,440 || trainable%: 0.109 / {'loss': 2.9, ...} ... adapter saved to ./lora-out"),
    ("rag_minimal.py", "Retrieval-augmented generation (Chapter 9)",
     "Embeds five sentences with MiniLM (mean-pooled, normalised, 384 dimensions), embeds the question the same way, retrieves the top two by cosine similarity, and asks a small instruction-tuned model to answer only from those passages with citations. The retrieval half runs in a second; the generation half downloads a 1 GB model on first use.",
     "[4] score 0.72  The Chinchilla scaling law recommends about twenty training tokens per parameter. / [1] score 0.31 ... / ANSWER: About twenty training tokens per parameter [4]."),
]
parts = ['<!-- PART: Appendix -->\n<div class="part">Appendix <span>Code and references</span></div>',
         '<h2><span class="n">15</span>Code: eight runnable programs</h2>',
         '<p class="lead">Each program is complete and runs as shown. The first three need only NumPy; the equation and integration scripts add SymPy and SciPy; the GPT needs PyTorch; the last two download open models from the Hugging Face Hub. All of them are modules of the <code>llmnote</code> package in the repository, installable with <code>pip install -e .</code>, with a test suite and continuous integration (Chapterwith a test suite and continuous integration (Chapter&nbsp;16)nbsp;16 shows the tools); the build scripts that produced every figure in this note are in the same place.</p>',
         '<div class="box g"><h4>Setup</h4><p><code>git clone https://github.com/dipakmunshi87/ML_Stat_Notes &amp;&amp; cd ML_Stat_Notes/code/llm_note &amp;&amp; pip install -e ".[dev]"</code>, then <code>pytest -q</code> (14 tests, about ten seconds on a CPU) and <code>llmnote-bigram</code>, <code>llmnote-attention</code>, &hellip; as console commands. The code repository is <a href="https://github.com/dipakmunshi87/ML_Stat_Notes/tree/main/code/llm_note">github.com/dipakmunshi87/ML_Stat_Notes/tree/main/code/llm_note</a>; <code>compute_llm.py</code> there regenerates every figure and every number in the text.</p></div>']
for i, (fn, title, desc, expected) in enumerate(scripts, 1):
    code = open(os.path.join(SRC, fn), encoding="utf-8").read()
    parts.append(f"<h3>15.{i} {title} &mdash; <code>{fn}</code></h3>\n<p>{desc}</p>\n<pre><code>{hl(code)}</code></pre>\n<p><strong>Expected output</strong> (abridged): <code>{html.escape(expected)}</code></p>")
parts.append('<div class="box"><h4>What to remember</h4><dl class="key"><dt>Bigram</dt><dd>A table of counts is a language model.</dd><dt>BPE</dt><dd>Merge the most frequent pair; replay the merges.</dd><dt>Attention</dt><dd>Scores, softmax, weighted sum &mdash; the rod numbers reproduce.</dd><dt>GPT</dt><dd>Seventy lines; the same object as a frontier model.</dd><dt>Equations</dt><dd>SymPy for exactness, SciPy for numbers, both checked against each other.</dd><dt>LoRA / RAG</dt><dd>Forty lines each to adapt and to ground an open model.</dd></dl></div>')
open(os.path.join(HERE, "chapters", "15_code.html"), "w", encoding="utf-8").write("\n".join(parts))
print("wrote 15_code.html")
