"""All figures and quoted numbers for the LLM note. Run: python compute_llm.py  (CPU, ~2 min)."""
import math, re, time, collections
import numpy as np
from lib import *

rng = np.random.default_rng(0)

# ============================================================== Ch1: bigram model by hand
sents = ["the cat sat on the mat", "the dog sat on the log", "the cat saw the dog"]
toks = [["<s>"] + s.split() + ["</s>"] for s in sents]
vocab = ["<s>", "the", "cat", "dog", "sat", "saw", "on", "mat", "log", "</s>"]
C = np.zeros((len(vocab), len(vocab)), int); idx = {w: i for i, w in enumerate(vocab)}
for t in toks:
    for a, b in zip(t[:-1], t[1:]): C[idx[a], idx[b]] += 1
rowsum = C.sum(1, keepdims=True); P = np.where(rowsum > 0, C / np.maximum(rowsum, 1), 0)
V("bg_n_tokens", int(sum(len(t) - 1 for t in toks)))       # transitions counted
V("bg_n_the", int(C[idx["the"]].sum()))
V("bg_p_the_cat", P[idx["the"], idx["cat"]], ".3f"); V("bg_p_the_dog", P[idx["the"], idx["dog"]], ".3f")
V("bg_p_the_mat", P[idx["the"], idx["mat"]], ".3f"); V("bg_p_the_log", P[idx["the"], idx["log"]], ".3f")
V("bg_p_s_the", P[idx["<s>"], idx["the"]], ".2f"); V("bg_p_cat_sat", P[idx["cat"], idx["sat"]], ".2f")
V("bg_p_sat_on", P[idx["sat"], idx["on"]], ".2f"); V("bg_p_on_the", P[idx["on"], idx["the"]], ".2f")
V("bg_p_dog_end", P[idx["dog"], idx["</s>"]], ".2f"); V("bg_p_dog_sat", P[idx["dog"], idx["sat"]], ".2f")
V("bg_c_the_cat", int(C[idx["the"], idx["cat"]])); V("bg_c_the_dog", int(C[idx["the"], idx["dog"]]))
V("bg_c_the_mat", int(C[idx["the"], idx["mat"]])); V("bg_c_the_log", int(C[idx["the"], idx["log"]]))
# greedy generation
w = "<s>"; out = []
for _ in range(12):
    nxt = vocab[int(np.argmax(P[idx[w]]))];
    if nxt == "</s>": break
    out.append(nxt); w = nxt
V("bg_greedy", " ".join(out))
# log-likelihood of a held-out sentence
test = ["<s>", "the", "dog", "sat", "on", "the", "mat", "</s>"]
lp = [P[idx[a], idx[b]] for a, b in zip(test[:-1], test[1:])]
ll = float(np.sum(np.log(lp))); n = len(lp)
V("bg_test_probs", " \\times ".join(f"{p:.3f}" for p in lp)); V("bg_test_prob", float(np.prod(lp)), ".5f")
V("bg_test_ll", ll, ".3f"); V("bg_test_n", n); V("bg_test_ce", -ll / n, ".3f"); V("bg_test_ppl", math.exp(-ll / n), ".2f")
V("bg_vocab", len(vocab)); V("bg_uniform_ppl", len(vocab) - 1)
# probability of an unseen bigram
V("bg_p_cat_log", P[idx["cat"], idx["log"]], ".0f")
f, ax = fig(7.2, 5.6)
im = ax.imshow(P, cmap="Blues", vmin=0, vmax=1)
ax.set_xticks(range(len(vocab))); ax.set_xticklabels(vocab, rotation=45, ha="right"); ax.set_yticks(range(len(vocab))); ax.set_yticklabels(vocab)
for i in range(len(vocab)):
    for j in range(len(vocab)):
        if C[i, j]: ax.text(j, i, f"{C[i,j]}\n{P[i,j]:.2f}", ha="center", va="center", fontsize=8, color="white" if P[i, j] > 0.55 else INK)
ax.set_xlabel("next word $w_{t+1}$"); ax.set_ylabel("current word $w_t$"); ax.grid(False)
ax.set_title("Bigram model from three sentences: counts and conditional probabilities $P(w_{t+1}\\mid w_t)$")
f.colorbar(im, ax=ax, fraction=0.035, label="probability"); save(f, "bigram_heatmap")

# ============================================================== Ch2: BPE by hand
def bpe_train(words, n_merges):
    vocab_w = {tuple(w) + ("</w>",): c for w, c in words.items()}
    merges = []
    for _ in range(n_merges):
        pairs = collections.Counter()
        for wt, c in vocab_w.items():
            for a, b in zip(wt[:-1], wt[1:]): pairs[(a, b)] += c
        if not pairs: break
        best, cnt = pairs.most_common(1)[0]
        merges.append((best, cnt))
        new = {}
        for wt, c in vocab_w.items():
            out, i = [], 0
            while i < len(wt):
                if i < len(wt) - 1 and (wt[i], wt[i + 1]) == best: out.append(wt[i] + wt[i + 1]); i += 2
                else: out.append(wt[i]); i += 1
            new[tuple(out)] = c
        vocab_w = new
    return merges, vocab_w
words = {"low": 5, "lower": 2, "newest": 6, "widest": 3}
merges, vw = bpe_train(words, 6)
for k, (pair, cnt) in enumerate(merges, 1):
    V(f"bpe_m{k}", f"{pair[0]}+{pair[1]}"); V(f"bpe_c{k}", cnt); V(f"bpe_tok{k}", (pair[0] + pair[1]).replace("</w>", "&lt;/w&gt;"))
V("bpe_final", ", ".join(" ".join(wt).replace("</w>", "&lt;/w&gt;") for wt in vw))
V("bpe_init_syms", len(set(ch for w in words for ch in w)) + 1)
# merge curve on a longer paragraph
text = open(os.path.join(HERE, "scripts", "tiny_gpt.py")).read()
para = re.search(r'text = \("""(.*?)"""', text, re.S).group(1)
wc = collections.Counter(para.split())
ntoks = []
for nm in range(0, 61, 5):
    m, vw2 = bpe_train(wc, nm); ntoks.append(sum(len(wt) * c for wt, c in vw2.items()))
V("bpe_para_chars", ntoks[0]); V("bpe_para_60", ntoks[-1]); V("bpe_para_words", sum(wc.values()))
f, ax = fig(7.6, 4.0)
ax.plot(range(0, 61, 5), ntoks, marker="o", color=BLUE); ax.axhline(sum(wc.values()), color=ORANGE, ls="--", label="one token per word")
ax.set_xlabel("number of BPE merges learned"); ax.set_ylabel("tokens needed for the paragraph"); ax.legend()
ax.set_title("Byte-pair encoding trades vocabulary size for sequence length"); save(f, "bpe_curve")

# ============================================================== Ch3: vectors, cosine, RoPE
E = {"king": np.array([0.9, 0.1, 0.3]), "queen": np.array([0.8, 0.3, 0.3]), "apple": np.array([0.1, 0.9, 0.2]), "orange": np.array([0.2, 0.8, 0.3]), "paris": np.array([0.3, 0.2, 0.9])}
def cos(a, b): return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b)))
V("cos_kq", cos(E["king"], E["queen"]), ".3f"); V("cos_ka", cos(E["king"], E["apple"]), ".3f"); V("cos_ao", cos(E["apple"], E["orange"]), ".3f"); V("cos_kp", cos(E["king"], E["paris"]), ".3f")
V("dot_kq", float(E["king"] @ E["queen"]), ".2f"); V("norm_k", float(np.linalg.norm(E["king"])), ".3f"); V("norm_q", float(np.linalg.norm(E["queen"])), ".3f")
pairs = [("king", "queen"), ("apple", "orange"), ("king", "apple"), ("king", "paris"), ("apple", "paris")]
f, ax = fig(7.4, 3.6)
vals = [cos(E[a], E[b]) for a, b in pairs]
ax.bar([f"{a}\n{b}" for a, b in pairs], vals, color=[AQUA if v > 0.8 else BLUE if v > 0.6 else ORANGE for v in vals])
for i, v in enumerate(vals): ax.text(i, v + 0.02, f"{v:.2f}", ha="center", fontsize=9.5)
ax.set_ylim(0, 1.1); ax.set_ylabel("cosine similarity"); ax.set_title("Three-number embeddings: similar things point the same way"); save(f, "cosine_bars")
# sinusoidal positions
d = 16; pos = np.arange(40)[:, None]; i = np.arange(d // 2)[None, :]
ang = pos / (10000 ** (2 * i / d)); PE = np.zeros((40, d)); PE[:, 0::2] = np.sin(ang); PE[:, 1::2] = np.cos(ang)
V("pe_dot_0_1", float(PE[0] @ PE[1]), ".2f"); V("pe_dot_0_5", float(PE[0] @ PE[5]), ".2f"); V("pe_dot_10_11", float(PE[10] @ PE[11]), ".2f")
# RoPE illustration
f, ax = fig(8.0, 3.8, ncols=2)
th = 0.4
for m, col in [(0, MUT), (1, BLUE), (2, AQUA), (3, ORANGE)]:
    R = np.array([[np.cos(m * th), -np.sin(m * th)], [np.sin(m * th), np.cos(m * th)]]); v = R @ np.array([1.0, 0.2])
    ax[0].annotate("", xy=v, xytext=(0, 0), arrowprops=dict(arrowstyle="->", color=col, lw=2)); ax[0].text(v[0] * 1.08, v[1] * 1.08, f"m={m}", color=col, fontsize=10)
ax[0].set_aspect("equal"); ax[0].set_xlim(-0.6, 1.3); ax[0].set_ylim(-0.3, 1.3); ax[0].set_title("RoPE: the same vector at positions $m = 0,1,2,3$\nis rotated by $m\\theta$")
offs = np.arange(-8, 9); q = np.array([1.0, 0.3]); k = np.array([0.8, 0.5])
def rot(v, a): return np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]]) @ v
for mpos, col in [(0, BLUE), (5, ORANGE)]:
    ax[1].plot(offs, [rot(q, mpos * th) @ rot(k, (mpos + o) * th) for o in offs], marker="o", ms=4, color=col, label=f"query at position {mpos}")
ax[1].set_xlabel("relative offset  $n - m$"); ax[1].set_ylabel("$q_m \\cdot k_n$"); ax[1].legend(); ax[1].set_title("The score depends only on the offset $n-m$")
save(f, "rope")
V("pe_d", d)

# ============================================================== Ch4: attention by hand (hot rod)
x = np.array([1.0, 1.0, 5.0, 1.0]); theta = np.deg2rad([0, 30, 60, 90]); Pm = np.stack([np.cos(theta), np.sin(theta)], 1)
beta = 4.0
S = Pm @ Pm.T; W = np.exp(beta * S); W /= W.sum(1, keepdims=True); y = W @ x
V("rod_x", ", ".join(f"{v:g}" for v in x)); V("rod_scores1", ", ".join(f"{v:.3f}" for v in S[0])); V("rod_exp1", ", ".join(f"{v:.1f}" for v in np.exp(beta * S[0])))
V("rod_expsum1", float(np.exp(beta * S[0]).sum()), ".1f"); V("rod_w1", ", ".join(f"{v:.3f}" for v in W[0])); V("rod_y1", y[0], ".2f"); V("rod_y", ", ".join(f"{v:.2f}" for v in y)); V("rod_beta", beta, "g")
V("rod_w1_terms", " + ".join(f"{w_:.3f}\\times{v:g}" for w_, v in zip(W[0], x)))
# content-dependent: key also carries the reading; query dislikes hot keys
K2 = np.concatenate([Pm, x[:, None] / 5], 1); Q2 = np.concatenate([Pm, 4.0 * (x[:, None] / 5 - 0.6)], 1)   # cool queries dislike hot keys, the hot query likes them
S2 = Q2 @ K2.T; W2 = np.exp(beta * S2); W2 /= W2.sum(1, keepdims=True); y2 = W2 @ x
V("rod_w1c", ", ".join(f"{v:.3f}" for v in W2[0])); V("rod_w3c", ", ".join(f"{v:.3f}" for v in W2[2])); V("rod_y1c", y2[0], ".2f"); V("rod_y3c", y2[2], ".2f"); V("rod_y3", y[2], ".2f"); V("rod_q1c", -1.6, ".1f"); V("rod_q3c", 1.6, ".1f")
f, ax = fig(8.4, 3.6, ncols=2)
for a, Wm, t in [(ax[0], W, "position-only keys: a smoothing kernel"), (ax[1], W2, "keys carry the reading: the kernel avoids the hot spot")]:
    im = a.imshow(Wm, cmap="Blues", vmin=0, vmax=0.8); a.set_xticks(range(4)); a.set_yticks(range(4)); a.set_xticklabels([f"key {j+1}" for j in range(4)]); a.set_yticklabels([f"query {j+1}" for j in range(4)]); a.grid(False)
    for i_ in range(4):
        for j in range(4): a.text(j, i_, f"{Wm[i_,j]:.2f}", ha="center", va="center", fontsize=9, color="white" if Wm[i_, j] > 0.45 else INK)
    a.set_title(t, fontsize=10.5)
save(f, "rod_attention")
# causal 8-token toy attention matrix
d8 = 8; rng2 = np.random.default_rng(3); H8 = rng2.normal(size=(8, d8)); Wq, Wk = rng2.normal(size=(d8, d8)) / 3, rng2.normal(size=(d8, d8)) / 3
A8 = (H8 @ Wq) @ (H8 @ Wk).T / np.sqrt(d8); A8[np.triu_indices(8, 1)] = -np.inf; A8 = np.exp(A8); A8 /= A8.sum(1, keepdims=True)
f, ax = fig(5.6, 4.6)
im = ax.imshow(A8, cmap="Blues"); ax.set_xticks(range(8)); ax.set_yticks(range(8)); ax.set_xticklabels([f"t{j}" for j in range(8)]); ax.set_yticklabels([f"t{j}" for j in range(8)]); ax.grid(False)
ax.set_xlabel("attended token (key)"); ax.set_ylabel("current token (query)"); ax.set_title("Causal attention: each row sums to 1 and is zero above the diagonal")
f.colorbar(im, ax=ax, fraction=0.04); save(f, "causal_attention")
V("sqrt_d64", math.sqrt(64), "g"); V("var_dot_64", 64)

# ============================================================== Ch5: parameter and FLOP counts
def params(d, L, Vv, T=0): return 12 * L * d * d, Vv * d, 12 * L * d * d + Vv * d + T * d
for name, d_, L_, V_, T_ in [("gpt2", 768, 12, 50257, 1024), ("l7b", 4096, 32, 32000, 0)]:
    core, emb, tot = params(d_, L_, V_, T_)
    V(f"{name}_core", core / 1e6, ".1f"); V(f"{name}_emb", emb / 1e6, ".1f"); V(f"{name}_tot", tot / 1e6, ".1f"); V(f"{name}_d", d_); V(f"{name}_L", L_); V(f"{name}_V", f"{V_:,}")
V("gpt2_pos", 1024 * 768 / 1e6, ".1f")
V("gpt3_flops", 6 * 175e9 * 300e9, ".2e"); V("gpt3_flops_h", "3.15\\times10^{23}")
V("l7b_train_flops", 6 * 6.7e9 * 2e12, ".1e")
V("a100_days", 6 * 175e9 * 300e9 / (312e12 * 0.4) / 86400 / 1000, ".0f")   # thousand-GPU days at 40% utilisation

# ============================================================== Ch6: training; softmax gradient; tiny_gpt loss curve
z = np.array([2.0, 1.0, 0.1, -1.0]); p = np.exp(z) / np.exp(z).sum(); yv = np.array([0, 1, 0, 0])
V("ce_logits", ", ".join(f"{v:g}" for v in z)); V("ce_probs", ", ".join(f"{v:.3f}" for v in p)); V("ce_loss", -math.log(p[1]), ".3f"); V("ce_p_correct", p[1], ".3f"); V("ce_grad", ", ".join(f"{v:+.3f}" for v in (p - yv)))
f, ax = fig(7.4, 3.6)
xs = np.arange(4); ax.bar(xs - 0.2, p, 0.4, color=BLUE, label="model probability $p_i$"); ax.bar(xs + 0.2, yv, 0.4, color=AQUA, label="target $y_i$ (one-hot)")
for i_, g in enumerate(p - yv): ax.annotate(f"grad {g:+.2f}", (i_, max(p[i_], yv[i_]) + 0.05), ha="center", fontsize=9, color=ORANGE)
ax.set_xticks(xs); ax.set_xticklabels(["token A", "token B (correct)", "token C", "token D"]); ax.set_ylim(0, 1.25); ax.legend(ncol=2)
ax.set_title("Softmax cross-entropy: the gradient on the logits is simply $p - y$"); save(f, "ce_gradient")
# tiny GPT training run (CPU), 300 steps
import torch, torch.nn as nn, torch.nn.functional as F
torch.manual_seed(0)
text = para * 40
chars = sorted(set(text)); Vc = len(chars); stoi = {c: i for i, c in enumerate(chars)}
data = torch.tensor([stoi[c] for c in text]); Tn, dm, Hh, Ll = 64, 64, 4, 2
class Attn(nn.Module):
    def __init__(s): super().__init__(); s.qkv = nn.Linear(dm, 3 * dm); s.out = nn.Linear(dm, dm); s.register_buffer("mask", torch.tril(torch.ones(Tn, Tn)))
    def forward(s, x):
        B, N, _ = x.shape; q, k, v = s.qkv(x).split(dm, dim=2); q, k, v = (t.view(B, N, Hh, dm // Hh).transpose(1, 2) for t in (q, k, v))
        att = (q @ k.transpose(-2, -1)) / math.sqrt(dm // Hh); att = att.masked_fill(s.mask[:N, :N] == 0, float("-inf")); att = F.softmax(att, -1)
        return s.out((att @ v).transpose(1, 2).reshape(B, N, dm))
class Block(nn.Module):
    def __init__(s): super().__init__(); s.ln1, s.ln2 = nn.LayerNorm(dm), nn.LayerNorm(dm); s.attn = Attn(); s.mlp = nn.Sequential(nn.Linear(dm, 4 * dm), nn.GELU(), nn.Linear(4 * dm, dm))
    def forward(s, x): x = x + s.attn(s.ln1(x)); return x + s.mlp(s.ln2(x))
class GPT(nn.Module):
    def __init__(s): super().__init__(); s.te = nn.Embedding(Vc, dm); s.pe = nn.Embedding(Tn, dm); s.blocks = nn.Sequential(*[Block() for _ in range(Ll)]); s.ln = nn.LayerNorm(dm); s.head = nn.Linear(dm, Vc)
    def forward(s, idx): B, N = idx.shape; return s.head(s.ln(s.blocks(s.te(idx) + s.pe(torch.arange(N)))))
model = GPT(); npar = sum(p_.numel() for p_ in model.parameters()); V("tg_params_k", npar / 1e3, ".0f"); V("tg_vocab", Vc); V("tg_lnV", math.log(Vc), ".2f")
opt = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=0.01); losses = []; t0 = time.time()
for step in range(300):
    ix = torch.randint(0, len(data) - Tn - 1, (32,)); xb = torch.stack([data[i_:i_ + Tn] for i_ in ix]); yb = torch.stack([data[i_ + 1:i_ + Tn + 1] for i_ in ix])
    loss = F.cross_entropy(model(xb).view(-1, Vc), yb.view(-1)); opt.zero_grad(); loss.backward(); opt.step(); losses.append(loss.item())
V("tg_loss0", losses[0], ".2f"); V("tg_loss300", float(np.mean(losses[-10:])), ".2f"); V("tg_ppl0", math.exp(losses[0]), ".1f"); V("tg_ppl300", math.exp(float(np.mean(losses[-10:]))), ".2f"); V("tg_seconds", time.time() - t0, ".0f")
f, ax = fig(7.6, 3.8)
ax.plot(losses, color=BLUE, lw=1.3, alpha=0.5); ax.plot(np.convolve(losses, np.ones(10) / 10, "valid"), color=BLUE, label="training loss (10-step mean)")
ax.axhline(math.log(Vc), color=ORANGE, ls="--", label=f"random guessing: $\\ln V = {math.log(Vc):.2f}$"); ax.set_xlabel("optimiser step"); ax.set_ylabel("cross-entropy (nats per character)"); ax.legend()
ax.set_title(f"A {npar/1e3:.0f}k-parameter GPT learning a paragraph: next-character loss on CPU"); save(f, "tinygpt_loss")

# ============================================================== Ch7: scaling laws and Chinchilla
Ec, A, B, al, be = 1.69, 406.4, 410.7, 0.34, 0.28
Lfun = lambda N, D: Ec + A / N**al + B / D**be
a_exp = be / (al + be); b_exp = al / (al + be); V("ch_a", a_exp, ".2f"); V("ch_b", b_exp, ".2f")
V("ch_E", Ec); V("ch_A", A); V("ch_B", B); V("ch_alpha", al); V("ch_beta", be)
G = ((al * A) / (be * B)) ** (1 / (al + be)); V("ch_G", G, ".3f")
def nopt(Cf): return G * (Cf / 6) ** a_exp
def dopt(Cf): return (1 / G) * (Cf / 6) ** b_exp
for tag, Cf in [("1e21", 1e21), ("1e23", 1e23), ("5e23", 5.76e23), ("1e25", 1e25)]:
    V(f"ch_N_{tag}", nopt(Cf) / 1e9, ".1f"); V(f"ch_D_{tag}", dopt(Cf) / 1e9, ".0f"); V(f"ch_ratio_{tag}", dopt(Cf) / nopt(Cf), ".0f")
V("ch_gpt3_loss", Lfun(175e9, 300e9), ".3f"); V("ch_chin_loss", Lfun(70e9, 1.4e12), ".3f"); V("ch_gpt3_C", 6 * 175e9 * 300e9, ".2e"); V("ch_chin_C", 6 * 70e9 * 1.4e12, ".2e")
f, ax = fig(8.6, 3.8, ncols=2)
Ns = np.logspace(8, 12, 100)
for Dv, col in [(1e10, YELLOW), (1e11, AQUA), (1e12, BLUE), (1e13, ORANGE)]: ax[0].loglog(Ns, Lfun(Ns, Dv), color=col, label=f"D = {Dv:.0e} tokens")
ax[0].axhline(Ec, color=MUT, ls=":", label="irreducible E"); ax[0].set_xlabel("parameters N"); ax[0].set_ylabel("loss (nats/token)"); ax[0].legend(fontsize=8.5); ax[0].set_title("Loss falls as a power law in N, until data runs out")
Cs = np.logspace(19, 26, 60); ax[1].loglog(Cs, nopt(Cs), color=BLUE, label="optimal N(C)"); ax[1].loglog(Cs, dopt(Cs), color=ORANGE, label="optimal D(C)")
ax[1].scatter([6 * 175e9 * 300e9], [175e9], color=BLUE, marker="x", s=60, zorder=5); ax[1].annotate("GPT-3 (175B, 300B tokens)", (6 * 175e9 * 300e9, 175e9), textcoords="offset points", xytext=(6, -14), fontsize=8.5)
ax[1].scatter([6 * 70e9 * 1.4e12], [1.4e12], color=ORANGE, marker="x", s=60, zorder=5); ax[1].annotate("Chinchilla (70B, 1.4T tokens)", (6 * 70e9 * 1.4e12, 1.4e12), textcoords="offset points", xytext=(6, 6), fontsize=8.5)
ax[1].set_xlabel("training compute C (FLOPs)"); ax[1].set_ylabel("count"); ax[1].legend(); ax[1].set_title("Compute-optimal size: $N \\propto C^{%.2f}$, $D \\propto C^{%.2f}$" % (a_exp, b_exp))
save(f, "scaling_laws")

# ============================================================== Ch8: DPO loss
f, ax = fig(7.2, 3.6)
m = np.linspace(-4, 4, 200)
for b_, col in [(0.1, YELLOW), (0.5, AQUA), (1.0, BLUE), (2.0, ORANGE)]: ax.plot(m, -np.log(1 / (1 + np.exp(-b_ * m))), color=col, label=f"$\\beta$ = {b_}")
ax.set_xlabel("implicit reward margin  $\\hat r(y_w) - \\hat r(y_l)$"); ax.set_ylabel("DPO loss  $-\\log\\sigma(\\beta\\,\\cdot\\,$margin$)$"); ax.legend(); ax.set_title("The DPO loss: push the preferred answer's log-ratio above the rejected one's")
save(f, "dpo_loss")
V("dpo_example", -math.log(1 / (1 + math.exp(-1.0 * 1.0))), ".3f")

# ============================================================== Ch9: LoRA parameter counts; RAG metrics
dL = 4096; full = dL * dL; V("lora_full_M", full / 1e6, ".1f")
for r_ in (1, 4, 8, 16, 64): V(f"lora_r{r_}_k", 2 * dL * r_ / 1e3, ".0f"); V(f"lora_r{r_}_pct", 100 * 2 * dL * r_ / full, ".2f")
V("lora_7b_r8_M", 2 * dL * 8 * 2 * 32 / 1e6, ".1f")   # q and v in 32 layers
f, ax = fig(7.2, 3.6)
rs = np.array([1, 2, 4, 8, 16, 32, 64, 128, 256]); ax.loglog(rs, 2 * dL * rs / 1e6, marker="o", color=BLUE, label="LoRA update $2dr$")
ax.axhline(full / 1e6, color=ORANGE, ls="--", label=f"full matrix $d^2$ = {full/1e6:.1f} M"); ax.set_xlabel("rank r"); ax.set_ylabel("trainable parameters per matrix (millions)"); ax.legend(); ax.set_title(f"LoRA at $d$ = {dL}: a rank-8 update is {100*2*dL*8/full:.2f}% of the matrix")
save(f, "lora_params")
# RAG toy metrics
ranks = [1, 3, 1, 2, 7, 1, 4, 1, 2, 11]
V("rag_hit1", np.mean([r_ <= 1 for r_ in ranks]), ".2f"); V("rag_hit5", np.mean([r_ <= 5 for r_ in ranks]), ".2f"); V("rag_mrr", np.mean([1 / r_ for r_ in ranks]), ".3f"); V("rag_ranks", ", ".join(map(str, ranks)))

# ============================================================== Ch10: temperature softmax
zl = np.array([3.0, 2.5, 1.0, 0.0, -1.0, -2.0]); labels = ["signal", "source", "galaxy", "noise", "pulsar", "banana"]
f, ax = fig(8.2, 3.6)
for Tt, col, off in [(0.5, ORANGE, -0.27), (1.0, BLUE, 0), (2.0, AQUA, 0.27)]:
    pt = np.exp(zl / Tt) / np.exp(zl / Tt).sum(); ax.bar(np.arange(6) + off, pt, 0.26, color=col, label=f"T = {Tt}")
    V(f"temp_T{str(Tt).replace('.','p')}_top", pt[0], ".3f"); V(f"temp_T{str(Tt).replace('.','p')}_last", pt[-1], ".4f")
ax.set_xticks(range(6)); ax.set_xticklabels(labels); ax.set_ylabel("probability"); ax.legend(); ax.set_title("The same logits at three temperatures: $p_i \\propto e^{z_i/T}$")
save(f, "temperature")
V("temp_logits", ", ".join(f"{v:g}" for v in zl))
pt = np.exp(zl); pt /= pt.sum(); cum = np.cumsum(pt); V("topp_k_09", int(np.searchsorted(cum, 0.9) + 1)); V("temp_cum", ", ".join(f"{v:.3f}" for v in cum))

# ============================================================== Ch11: Hopfield energy illustration (retrieval)
rng3 = np.random.default_rng(7); patt = rng3.choice([-1, 1], size=(3, 24)).astype(float)
xq = patt[0].copy(); flip = rng3.choice(24, 6, replace=False); xq[flip] *= -1
betaH = 1.0
def hop_update(xi): w_ = np.exp(betaH * patt @ xi); w_ /= w_.sum(); return patt.T @ w_
x1 = hop_update(xq); x2 = hop_update(x1)
V("hop_overlap0", float(xq @ patt[0]) / 24, ".2f"); V("hop_overlap1", float(np.sign(x1) @ patt[0]) / 24, ".2f"); V("hop_overlap2", float(np.sign(x2) @ patt[0]) / 24, ".2f"); V("hop_nflip", 6); V("hop_N", 24)
f, ax = fig(8.0, 2.6)
ax.imshow(np.stack([patt[0], xq, np.sign(x1), np.sign(x2)]), cmap="Blues", aspect="auto"); ax.set_yticks(range(4)); ax.set_yticklabels(["stored pattern", "corrupted query (6 flips)", "after 1 update", "after 2 updates"]); ax.set_xticks([]); ax.grid(False)
ax.set_title("Attention as associative memory: one softmax update retrieves the stored pattern"); save(f, "hopfield")

# ============================================================== Ch12: map of modern directions (diagram)
f, ax = fig(9.0, 5.2); ax.set_axis_off(); ax.set_xlim(0, 10); ax.set_ylim(0, 6)
from matplotlib.patches import FancyBboxPatch
def box(x_, y_, w_, h_, t, col, fs=9.5):
    ax.add_patch(FancyBboxPatch((x_, y_), w_, h_, boxstyle="round,pad=0.08", fc=col, ec="none", alpha=0.18)); ax.add_patch(FancyBboxPatch((x_, y_), w_, h_, boxstyle="round,pad=0.08", fc="none", ec=col, lw=1.6))
    ax.text(x_ + w_ / 2, y_ + h_ / 2, t, ha="center", va="center", fontsize=fs, color=INK, wrap=True)
box(3.6, 2.4, 2.8, 1.2, "Transformer LLM\n(attention + MLP, next-token training)", BLUE, 10.5)
items = [(0.2, 4.6, "Cheaper compute\nmixture of experts · quantisation\ndistillation · efficient attention", AQUA), (3.6, 4.6, "Longer memory\nlong context · RAG\nstate-space models (Mamba)", ORANGE),
         (7.0, 4.6, "More senses\nimages · audio · video\nmolecules · fields", MAGENTA), (0.2, 0.2, "Better behaviour\nSFT · RLHF / DPO\nconstitutions · evaluation", YELLOW),
         (3.6, 0.2, "Thinking longer\nchain of thought · search\ntest-time compute · verifiers", AQUA), (7.0, 0.2, "Acting\ntool use · code execution\nagents · science assistants", BLUE)]
for x_, y_, t, col in items:
    box(x_, y_, 2.8, 1.2, t, col)
    cx, cy = x_ + 1.4, (y_ if y_ > 3 else y_ + 1.2); ax.annotate("", xy=(cx, cy), xytext=(5.0, 3.0 if y_ > 3 else 3.0), arrowprops=dict(arrowstyle="-", color=MUT, lw=1, alpha=0.6))
ax.set_title("Where the field is going: six directions, all starting from the same architecture"); save(f, "directions_map")

# ============================================================== Ch13: energy numbers (literature values, recorded for the text)
V("gpt3_mwh", 1287); V("gpt3_tco2", 552); V("query_wh", 0.3); V("query_wh_hi", 3); V("kettle_wh", 100)
V("hum_tokens_day", "10^{12}")

# ============================================================== EXTRA worked examples (revision)
# trigram by hand (Ch1): contexts of two words in the same 3-sentence corpus
tri = collections.Counter(); bi_ctx = collections.Counter()
for t in toks:
    for a, b, c in zip(t[:-2], t[1:-1], t[2:]): tri[(a, b, c)] += 1; bi_ctx[(a, b)] += 1
V("tri_n", sum(tri.values())); V("tri_ctx_the_cat", bi_ctx[("the", "cat")]); V("tri_the_cat_sat", tri[("the", "cat", "sat")]); V("tri_the_cat_saw", tri[("the", "cat", "saw")])
V("tri_p_sat_given_the_cat", tri[("the", "cat", "sat")] / bi_ctx[("the", "cat")], ".2f"); V("tri_ctx_on_the", bi_ctx[("on", "the")])
V("tri_p_mat_given_on_the", tri[("on", "the", "mat")] / bi_ctx[("on", "the")], ".2f"); V("tri_p_log_given_on_the", tri[("on", "the", "log")] / bi_ctx[("on", "the")], ".2f")
V("tri_p_dog_given_on_the", tri[("on", "the", "dog")] / bi_ctx[("on", "the")], ".2f"); V("tri_n_ctx", len(bi_ctx)); V("tri_V2", len(vocab) ** 2)
# 2-d embeddings of four words (Ch3)
E2 = {"hot": (0.9, 0.2), "warm": (0.8, 0.4), "cold": (-0.7, 0.3), "ice": (-0.9, 0.1)}
import itertools as _it
for a, b in _it.combinations(E2, 2):
    va, vb = np.array(E2[a]), np.array(E2[b]); V(f"e2_dot_{a}_{b}", float(va @ vb), ".2f"); V(f"e2_cos_{a}_{b}", cos(va, vb), ".2f")
for a in E2: V(f"e2_norm_{a}", float(np.linalg.norm(E2[a])), ".3f")
# second rod example (Ch4): readings [2,2,2,8], hot spot at the end
x2 = np.array([2.0, 2.0, 2.0, 8.0]); theta2 = np.deg2rad([0, 30, 60, 90]); P2 = np.stack([np.cos(theta2), np.sin(theta2)], 1)
S2p = P2 @ P2.T; W2p = np.exp(4.0 * S2p); W2p /= W2p.sum(1, keepdims=True); y2p = W2p @ x2
K3 = np.concatenate([P2, x2[:, None] / 8], 1); Q3 = np.concatenate([P2, 4.0 * (x2[:, None] / 8 - 0.6)], 1)
S3 = Q3 @ K3.T; W3 = np.exp(4.0 * S3); W3 /= W3.sum(1, keepdims=True); y3 = W3 @ x2
V("rod2_x", ", ".join(f"{v:g}" for v in x2)); V("rod2_w3_pos", ", ".join(f"{v:.3f}" for v in W2p[2])); V("rod2_y3_pos", y2p[2], ".2f")
V("rod2_k4", ", ".join(f"{v:.3f}" for v in K3[3])); V("rod2_q3", ", ".join(f"{v:.3f}" for v in Q3[2])); V("rod2_s3", ", ".join(f"{v:.3f}" for v in S3[2]))
V("rod2_e3", ", ".join(f"{v:.2f}" for v in np.exp(4.0 * S3[2]))); V("rod2_w3", ", ".join(f"{v:.3f}" for v in W3[2])); V("rod2_y3", y3[2], ".2f"); V("rod2_y4", y3[3], ".2f"); V("rod2_y4_pos", y2p[3], ".2f")
# 3-class gradient and one SGD step by hand (Ch6)
z3 = np.array([1.0, 2.0, 0.5]); p3 = np.exp(z3) / np.exp(z3).sum(); y3c = np.array([1, 0, 0]); eta = 0.5
V("sgd_logits", ", ".join(f"{v:g}" for v in z3)); V("sgd_exps", ", ".join(f"{v:.3f}" for v in np.exp(z3))); V("sgd_Z", float(np.exp(z3).sum()), ".3f")
V("sgd_probs", ", ".join(f"{v:.3f}" for v in p3)); V("sgd_loss", -math.log(p3[0]), ".3f"); V("sgd_p1", p3[0], ".3f"); V("sgd_grad", ", ".join(f"{v:+.3f}" for v in (p3 - y3c)))
z3n = z3 - eta * (p3 - y3c); p3n = np.exp(z3n) / np.exp(z3n).sum()
V("sgd_eta", eta, "g"); V("sgd_new_logits", ", ".join(f"{v:.3f}" for v in z3n)); V("sgd_new_probs", ", ".join(f"{v:.3f}" for v in p3n)); V("sgd_new_loss", -math.log(p3n[0]), ".3f")
# decoding by hand: three logits at T = 0.5, 1, 2 (Ch10)
zd = np.array([2.0, 1.0, 0.0])
for Tt in (0.5, 1.0, 2.0):
    e = np.exp(zd / Tt); V(f"dec_T{str(Tt).replace('.','p')}_exps", ", ".join(f"{v:.3f}" for v in e)); V(f"dec_T{str(Tt).replace('.','p')}_Z", float(e.sum()), ".3f"); V(f"dec_T{str(Tt).replace('.','p')}_p", ", ".join(f"{v:.3f}" for v in e / e.sum()))
# RAG top-k over 4 toy passages by hand (Ch9) -- 3-d embeddings
Pg = {"A": (0.9, 0.1, 0.2), "B": (0.2, 0.9, 0.1), "C": (0.7, 0.5, 0.3), "D": (0.1, 0.2, 0.9)}; qv = np.array((0.8, 0.3, 0.1))
V("ragh_q_norm", float(np.linalg.norm(qv)), ".3f")
for k_, v_ in Pg.items(): vv = np.array(v_); V(f"ragh_dot_{k_}", float(qv @ vv), ".2f"); V(f"ragh_norm_{k_}", float(np.linalg.norm(vv)), ".3f"); V(f"ragh_cos_{k_}", cos(qv, vv), ".3f")
# heat equation figure (new chapter): u_t = D u_xx on [0,L], u(0)=u(L)=0, u(x,0)=triangle
Lh, Dh = 1.0, 0.01; xs_h = np.linspace(0, Lh, 400); u0 = np.where(xs_h < 0.5, 2 * xs_h, 2 * (1 - xs_h))
def bn(n_): return 2 / Lh * np.trapezoid(u0 * np.sin(n_ * np.pi * xs_h / Lh), xs_h)
coef = [bn(n_) for n_ in range(1, 40)]
def uh(t_): return sum(b_ * np.sin(n_ * np.pi * xs_h / Lh) * np.exp(-Dh * (n_ * np.pi / Lh) ** 2 * t_) for n_, b_ in enumerate(coef, 1))
V("heat_b1", coef[0], ".3f"); V("heat_b3", coef[2], ".3f"); V("heat_b1_exact", 8 / np.pi ** 2, ".3f"); V("heat_tau1", 1 / (Dh * np.pi ** 2), ".1f"); V("heat_tau3", 1 / (Dh * 9 * np.pi ** 2), ".2f"); V("heat_D", Dh)
f, ax = fig(7.8, 4.0)
for t_, col in [(0, INK), (0.5, BLUE), (2, AQUA), (5, YELLOW), (10, ORANGE), (25, MAGENTA)]: ax.plot(xs_h, uh(t_), color=col, label=f"t = {t_:g}")
ax.set_xlabel("x"); ax.set_ylabel("u(x, t)"); ax.legend(ncol=3); ax.set_title(f"Heat equation on [0, 1], D = {Dh}: the sine series decays mode by mode, slowest first")
save(f, "heat_equation")
flush()

# ============================================================== integration and linear algebra by hand (Ch 11.10)
import sys as _sys; _sys.path.insert(0, os.path.join(HERE, "..", "src")); _sys.path.insert(0, os.path.join(HERE, "repo", "src"))
from llmnote import integrate_demo as _q
fx = lambda t_: math.exp(-t_ * t_)
xs4 = [0, 0.25, 0.5, 0.75, 1.0]; fs4 = [fx(t_) for t_ in xs4]
V("simp_f", ", ".join(f"{v:.6f}" for v in fs4)); V("simp_sum", fs4[0] + 4 * fs4[1] + 2 * fs4[2] + 4 * fs4[3] + fs4[4], ".6f")
V("simp_val", _q.simpson(_q.F, 0, 1, 4), ".6f"); V("simp_err", abs(_q.simpson(_q.F, 0, 1, 4) - _q.EXACT), ".1e"); V("int_exact", _q.EXACT, ".6f")
V("trap_val4", _q.trapezoid(_q.F, 0, 1, 4), ".6f"); V("trap_err4", abs(_q.trapezoid(_q.F, 0, 1, 4) - _q.EXACT), ".1e")
g1, g2 = 0.5 - 0.5 / math.sqrt(3), 0.5 + 0.5 / math.sqrt(3)
V("gl_x1", g1, ".6f"); V("gl_x2", g2, ".6f"); V("gl_f1", fx(g1), ".6f"); V("gl_f2", fx(g2), ".6f"); V("gl_val", 0.5 * (fx(g1) + fx(g2)), ".6f"); V("gl_err", abs(0.5 * (fx(g1) + fx(g2)) - _q.EXACT), ".1e")
mc_est, mc_se = _q.monte_carlo(_q.F, 0, 1, 10000); V("mc_est", mc_est, ".5f"); V("mc_se", mc_se, ".5f"); V("mc_dev_sigma", abs(mc_est - _q.EXACT) / mc_se, ".1f")
V("simp_err256", abs(_q.simpson(_q.F, 0, 1, 256) - _q.EXACT), ".1e"); V("trap_err256", abs(_q.trapezoid(_q.F, 0, 1, 256) - _q.EXACT), ".1e")
_q.make_figure(os.path.join(FIGD, "integration_error.png"), colors=SERIES); print("fig integration_error")
# Gaussian elimination by hand on 2x+y-z=8, -3x-y+2z=-11, -2x+y+2z=-3
A3 = np.array([[2.0, 1.0, -1.0], [-3.0, -1.0, 2.0], [-2.0, 1.0, 2.0]]); b3 = np.array([8.0, -11.0, -3.0]); V("ge_sol", ", ".join(f"{v:g}" for v in np.linalg.solve(A3, b3)))
flush()
print("done")
