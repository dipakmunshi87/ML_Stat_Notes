See ../README.md. Run: npm install; python compute_llm.py; python make_code_chapter.py; python build.py; python make_preview.py
