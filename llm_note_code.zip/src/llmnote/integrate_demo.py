"""Numerical integration from scratch: midpoint, trapezoid, Simpson, Gauss-Legendre and Monte Carlo on the same
integral, with an error-vs-N table and a figure (note, Chapter 11)."""
import argparse
import math

import numpy as np

F = lambda x: np.exp(-(x**2))  # noqa: E731
EXACT = math.sqrt(math.pi) / 2 * math.erf(1.0)  # int_0^1 e^{-x^2} dx


def midpoint(f, a, b, n):
    h = (b - a) / n
    x = a + h * (np.arange(n) + 0.5)
    return h * f(x).sum()


def trapezoid(f, a, b, n):
    x = np.linspace(a, b, n + 1)
    y = f(x)
    return (b - a) / n * (y[0] / 2 + y[1:-1].sum() + y[-1] / 2)


def simpson(f, a, b, n):
    if n % 2:
        raise ValueError("Simpson needs an even number of intervals")
    x = np.linspace(a, b, n + 1)
    y = f(x)
    return (b - a) / n / 3 * (y[0] + 4 * y[1:-1:2].sum() + 2 * y[2:-1:2].sum() + y[-1])


def gauss_legendre(f, a, b, n):
    """n-point Gauss-Legendre on [a, b] (nodes from numpy)."""
    xg, wg = np.polynomial.legendre.leggauss(n)
    x = 0.5 * (b - a) * xg + 0.5 * (b + a)
    return 0.5 * (b - a) * (wg * f(x)).sum()


def monte_carlo(f, a, b, n, seed=0):
    """Returns (estimate, standard error)."""
    rng = np.random.default_rng(seed)
    y = f(rng.uniform(a, b, n))
    return (b - a) * y.mean(), (b - a) * y.std(ddof=1) / math.sqrt(n)


def error_table(Ns=(2, 4, 8, 16, 32, 64, 128, 256)):
    rows = []
    for n in Ns:
        rows.append(dict(N=n, midpoint=abs(midpoint(F, 0, 1, n) - EXACT), trapezoid=abs(trapezoid(F, 0, 1, n) - EXACT),
                         simpson=abs(simpson(F, 0, 1, n) - EXACT), gauss=abs(gauss_legendre(F, 0, 1, min(n, 20)) - EXACT),
                         monte_carlo=abs(monte_carlo(F, 0, 1, n * n)[0] - EXACT)))
    return rows


def make_figure(path, colors=None):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    c = colors or ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]
    rows = error_table()
    N = np.array([r["N"] for r in rows])
    fig, ax = plt.subplots(figsize=(7.6, 4.2))
    for key, col, lab in [("midpoint", c[0], "midpoint  ~ N$^{-2}$"), ("trapezoid", c[1], "trapezoid  ~ N$^{-2}$"), ("simpson", c[2], "Simpson  ~ N$^{-4}$"),
                          ("gauss", c[3], "Gauss-Legendre (n = min(N, 20) points)"), ("monte_carlo", c[4], "Monte Carlo with N$^2$ samples  ~ N$^{-1}$")]:
        e = np.array([max(r[key], 1e-17) for r in rows])
        ax.loglog(N, e, marker="o", ms=4, color=col, label=lab)
    ax.set_xlabel("number of intervals N"); ax.set_ylabel("absolute error"); ax.legend(fontsize=8.5)
    ax.set_title(r"$\int_0^1 e^{-x^2}\,dx$: error of five quadrature rules against N")
    fig.tight_layout(); fig.savefig(path, dpi=110); plt.close(fig)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--figure", default=None, help="write the error-vs-N figure to this path")
    a = ap.parse_args()
    print(f"exact: {EXACT:.12f}")
    print(f"{'N':>5} {'midpoint':>12} {'trapezoid':>12} {'simpson':>12} {'gauss':>12} {'MC(N^2)':>12}")
    for r in error_table():
        print(f"{r['N']:5d} {r['midpoint']:12.2e} {r['trapezoid']:12.2e} {r['simpson']:12.2e} {r['gauss']:12.2e} {r['monte_carlo']:12.2e}")
    est, se = monte_carlo(F, 0, 1, 10000)
    print(f"Monte Carlo, 10000 samples: {est:.5f} +- {se:.5f}  (exact {EXACT:.5f})")
    if a.figure:
        print("figure ->", make_figure(a.figure))


if __name__ == "__main__":
    main()
