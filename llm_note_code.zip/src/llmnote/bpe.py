"""Byte-pair encoding from scratch: learn merges on a tiny corpus, then tokenise new words (note, Chapter 2)."""
import collections

WORDS = {"low": 5, "lower": 2, "newest": 6, "widest": 3}


def pair_counts(corpus):
    pc = collections.Counter()
    for sym, c in corpus.items():
        for a, b in zip(sym[:-1], sym[1:]):
            pc[(a, b)] += c
    return pc


def merge(corpus, pair):
    out = {}
    for sym, c in corpus.items():
        new, i = [], 0
        while i < len(sym):
            if i < len(sym) - 1 and (sym[i], sym[i + 1]) == pair:
                new.append(sym[i] + sym[i + 1])
                i += 2
            else:
                new.append(sym[i])
                i += 1
        out[tuple(new)] = c
    return out


def learn(words=WORDS, n_merges=8, verbose=False):
    """Return the ordered list of (pair, count) merges learned from a word-frequency dict."""
    corpus = {tuple(w) + ("</w>",): c for w, c in words.items()}
    merges = []
    for step in range(n_merges):
        pc = pair_counts(corpus)
        if not pc:
            break
        pair, cnt = pc.most_common(1)[0]
        merges.append((pair, cnt))
        corpus = merge(corpus, pair)
        if verbose:
            print(f"merge {step+1}: {pair[0]}+{pair[1]} (count {cnt}) ->", {" ".join(s): c for s, c in corpus.items()})
    return merges


def tokenise(word, merges):
    """Apply learned merges, in order, to a new word."""
    sym = tuple(word) + ("</w>",)
    for pair, _ in merges:
        sym = next(iter(merge({sym: 1}, pair)))
    return list(sym)


def main():
    merges = learn(verbose=True)
    print("lowest ->", tokenise("lowest", merges), "   newer ->", tokenise("newer", merges))


if __name__ == "__main__":
    main()
