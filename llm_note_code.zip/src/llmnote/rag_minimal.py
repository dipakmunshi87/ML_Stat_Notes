"""Retrieval-augmented generation in 40 lines: embed, retrieve by cosine, answer from the passages (note, Chapter 9).
The retrieval half (MiniLM) runs in seconds; the generation half downloads a ~1 GB instruct model on first use."""
import argparse

DOCS = [
    "Radio-frequency interference from satellites contaminates MeerKAT L-band observations near 1.2 GHz.",
    "A masked autoencoder is trained to reconstruct hidden patches from visible ones.",
    "The Black-Scholes equation becomes the heat equation after a change of variables.",
    "Byte-pair encoding builds a vocabulary by repeatedly merging the most frequent symbol pair.",
    "The Chinchilla scaling law recommends about twenty training tokens per parameter.",
]


def cosine_topk(E, q, k=2):
    """Top-k indices and scores by cosine similarity, for row-normalised E and unit q (pure numpy)."""
    import numpy as np

    scores = E @ q
    top = np.argsort(-scores)[:k]
    return top.tolist(), scores[top].tolist()


def embed(texts, name="sentence-transformers/all-MiniLM-L6-v2"):
    """Mean-pooled, L2-normalised sentence embeddings (numpy array, one row per text)."""
    import torch
    from transformers import AutoModel, AutoTokenizer

    tok, mod = AutoTokenizer.from_pretrained(name), AutoModel.from_pretrained(name)
    b = tok(texts, padding=True, truncation=True, return_tensors="pt")
    with torch.no_grad():
        h = mod(**b).last_hidden_state
    m = b["attention_mask"][..., None]
    v = (h * m).sum(1) / m.sum(1)
    return torch.nn.functional.normalize(v, dim=1).numpy()


def answer(question, passages, name="Qwen/Qwen2.5-0.5B-Instruct", max_new_tokens=60):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok, llm = AutoTokenizer.from_pretrained(name), AutoModelForCausalLM.from_pretrained(name)
    context = "\n".join(f"[{i}] {p}" for i, p in passages)
    msgs = [{"role": "system", "content": "Answer only from the passages and cite them as [n]. If they do not contain the answer, say so."},
            {"role": "user", "content": f"Passages:\n{context}\n\nQuestion: {question}"}]
    text = tok.apply_chat_template(msgs, add_generation_prompt=True, tokenize=False)
    inp = tok(text, return_tensors="pt")
    with torch.no_grad():
        out = llm.generate(**inp, max_new_tokens=max_new_tokens, do_sample=False)
    return tok.decode(out[0][inp["input_ids"].shape[1] :], skip_special_tokens=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--question", default="How many tokens per parameter should I train a language model on?")
    ap.add_argument("--no-generate", action="store_true", help="retrieval only (no 1 GB download)")
    a = ap.parse_args()
    E = embed(DOCS)
    q = embed([a.question])[0]
    top, scores = cosine_topk(E, q, 2)
    for i, s in zip(top, scores):
        print(f"[{i}] score {s:.3f}  {DOCS[i]}")
    if not a.no_generate:
        print("\nANSWER:", answer(a.question, [(i, DOCS[i]) for i in top]))


if __name__ == "__main__":
    main()
