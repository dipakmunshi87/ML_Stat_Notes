"""The equations of the note's Chapter 11, solved symbolically (sympy) and numerically (numpy/scipy), with
the two routes compared. This is the script a tool-using model writes and runs instead of doing algebra in its head."""
import math

import numpy as np
import sympy as sp
from scipy import integrate


def symbolic():
    """Exact solutions with sympy. Returns a dict of results (sympy objects)."""
    x, t, k, w, y0 = sp.symbols("x t k omega y0", positive=True)
    y = sp.Function("y")
    r = {}
    r["linear"] = sp.solve(3 * x + 7 - 22, x)                                        # [5]
    r["quadratic_factor"] = sp.factor(x**2 - 5 * x + 6)                                # (x-2)(x-3)
    r["quadratic_roots"] = sp.solve(x**2 - 5 * x + 6, x)                               # [2, 3]
    u, v = sp.symbols("u v")
    r["system"] = sp.solve([2 * u + 3 * v - 12, u - v - 1], [u, v])                    # {u: 3, v: 2}
    ode_decay = sp.Eq(y(x).diff(x), -k * y(x))
    r["decay"] = sp.dsolve(ode_decay, ics={y(0): y0})                                  # y = y0*exp(-k x)
    ode_lin = sp.Eq(y(x).diff(x) + 2 * y(x), sp.exp(-x))
    r["linear_ode"] = sp.dsolve(ode_lin)                                               # (C1 + e^x) e^{-2x}
    r["linear_ode_check"] = sp.checkodesol(ode_lin, r["linear_ode"])                   # (True, 0)
    ode_sho = sp.Eq(y(t).diff(t, 2) + w**2 * y(t), 0)
    r["sho"] = sp.dsolve(ode_sho, ics={y(0): 1, y(t).diff(t).subs(t, 0): 0})           # cos(omega t)
    n = sp.symbols("n", integer=True, positive=True)
    f = sp.Piecewise((2 * x, x < sp.Rational(1, 2)), (2 * (1 - x), True))
    b_n = 2 * sp.integrate(f * sp.sin(n * sp.pi * x), (x, 0, 1))
    r["heat_b1"] = sp.simplify(b_n.subs(n, 1))                                         # 8/pi**2
    r["heat_b2"] = sp.simplify(b_n.subs(n, 2))                                         # 0
    r["heat_b3"] = sp.simplify(b_n.subs(n, 3))                                         # -8/(9 pi**2)
    r["int_x2"] = sp.integrate(x**2, (x, 0, 1))                                        # 1/3
    r["int_sin"] = sp.integrate(sp.sin(x), (x, 0, sp.pi))                              # 2
    r["int_gauss"] = sp.integrate(sp.exp(-(x**2)), (x, 0, 1))                          # sqrt(pi) erf(1)/2
    return r


def numerical():
    """The same problems by numerical linear algebra, quadrature and ODE integration (numpy/scipy)."""
    r = {}
    A = np.array([[2.0, 3.0], [1.0, -1.0]])
    b = np.array([12.0, 1.0])
    r["system"] = np.linalg.solve(A, b)                                                # [3, 2]
    A3 = np.array([[2.0, 1.0, -1.0], [-3.0, -1.0, 2.0], [-2.0, 1.0, 2.0]])
    b3 = np.array([8.0, -11.0, -3.0])
    r["system3"] = np.linalg.solve(A3, b3)                                              # [2, 3, -1]
    r["int_x2"] = integrate.quad(lambda x: x**2, 0, 1)[0]
    r["int_sin"] = integrate.quad(np.sin, 0, np.pi)[0]
    r["int_gauss"], r["int_gauss_err"] = integrate.quad(lambda x: np.exp(-(x**2)), 0, 1)
    k, y0 = 0.5, 2.0
    sol = integrate.solve_ivp(lambda x, y: -k * y, (0, 4), [y0], rtol=1e-10, atol=1e-12, dense_output=True)
    r["decay_num_at_4"], r["decay_exact_at_4"] = float(sol.sol(4)[0]), y0 * math.exp(-k * 4)
    sol = integrate.solve_ivp(lambda x, y: np.exp(-x) - 2 * y, (0, 3), [1.0], rtol=1e-10, atol=1e-12, dense_output=True)
    r["linear_ode_num_at_3"], r["linear_ode_exact_at_3"] = float(sol.sol(3)[0]), math.exp(-3) + 0 * math.exp(-6)  # C = 0 for y(0) = 1
    w = 2.0
    sol = integrate.solve_ivp(lambda t, s: [s[1], -(w**2) * s[0]], (0, 5), [1.0, 0.0], rtol=1e-10, atol=1e-12, dense_output=True)
    r["sho_num_at_5"], r["sho_exact_at_5"] = float(sol.sol(5)[0]), math.cos(w * 5)
    return r


def main():
    s, n = symbolic(), numerical()
    print("--- symbolic (sympy)")
    for k_, v_ in s.items():
        print(f"{k_:20s} {v_}")
    print("--- numerical (numpy / scipy) vs analytic")
    print(f"{'2x2 system':20s} {n['system']}   (sympy: {s['system']})")
    print(f"{'3x3 system':20s} {n['system3']}   (by hand: [2, 3, -1])")
    print(f"{'int x^2 [0,1]':20s} {n['int_x2']:.12f}   exact 1/3 = {1/3:.12f}")
    print(f"{'int sin [0,pi]':20s} {n['int_sin']:.12f}   exact 2")
    print(f"{'int e^-x^2 [0,1]':20s} {n['int_gauss']:.12f} +- {n['int_gauss_err']:.1e}   exact {float(s['int_gauss']):.12f}")
    print(f"{'decay y(4)':20s} {n['decay_num_at_4']:.10f}   exact {n['decay_exact_at_4']:.10f}")
    print(f"{'linear ODE y(3)':20s} {n['linear_ode_num_at_3']:.10f}   exact {n['linear_ode_exact_at_3']:.10f}")
    print(f"{'SHO x(5)':20s} {n['sho_num_at_5']:.10f}   exact {n['sho_exact_at_5']:.10f}")


if __name__ == "__main__":
    main()
