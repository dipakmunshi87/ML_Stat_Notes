"""LoRA fine-tuning of a small open model with Hugging Face `peft` (note, Chapter 9).
pip install -e ".[gpu]"   then   llmnote-lora [--model Qwen/Qwen2.5-0.5B] [--steps 60] [--device cuda]
Needs a GPU for comfort; on pre-Ampere cards (no bf16) pass --fp16."""
import argparse


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen2.5-0.5B")
    ap.add_argument("--steps", type=int, default=60)
    ap.add_argument("--rank", type=int, default=8)
    ap.add_argument("--fp16", action="store_true", help="use fp16 instead of bf16 (older GPUs)")
    ap.add_argument("--out", default="./lora-out")
    a = ap.parse_args()

    import torch
    from datasets import load_dataset
    from peft import LoraConfig, get_peft_model
    from transformers import AutoModelForCausalLM, AutoTokenizer, DataCollatorForLanguageModeling, Trainer, TrainingArguments

    tok = AutoTokenizer.from_pretrained(a.model)
    tok.pad_token = tok.eos_token
    dtype = torch.float16 if a.fp16 else (torch.bfloat16 if torch.cuda.is_available() else torch.float32)
    model = AutoModelForCausalLM.from_pretrained(a.model, torch_dtype=dtype)

    # 1. freeze the base model, add rank-r adapters to the attention query and value matrices
    lora = LoraConfig(r=a.rank, lora_alpha=2 * a.rank, lora_dropout=0.05, target_modules=["q_proj", "v_proj"], task_type="CAUSAL_LM")
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()  # ~0.1% of the weights

    # 2. domain data: any dataset with a text field (swap for your own JSONL of reports / abstracts)
    ds = load_dataset("wikitext", "wikitext-2-raw-v1", split="train[:2000]")
    ds = ds.filter(lambda r: len(r["text"]) > 50)
    ds = ds.map(lambda r: tok(r["text"], truncation=True, max_length=256), batched=True, remove_columns=ds.column_names)

    # 3. the standard training loop
    args = TrainingArguments(a.out, per_device_train_batch_size=4, gradient_accumulation_steps=4, max_steps=a.steps, learning_rate=2e-4,
                             logging_steps=10, save_strategy="no", bf16=not a.fp16 and torch.cuda.is_available(), fp16=a.fp16, report_to=[])
    Trainer(model=model, args=args, train_dataset=ds, data_collator=DataCollatorForLanguageModeling(tok, mlm=False)).train()
    model.save_pretrained(a.out)  # only the adapter (a few MB) is written
    print("adapter saved to", a.out)


if __name__ == "__main__":
    main()
