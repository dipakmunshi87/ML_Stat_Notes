"""Attention on four temperature readings along a rod, every number printed (note, Chapter 4)."""
import numpy as np


def softmax_rows(S, beta=1.0):
    W = np.exp(beta * (S - S.max(1, keepdims=True)))
    return W / W.sum(1, keepdims=True)


def attention(Q, K, V, beta=4.0):
    """Return (weights, output) for queries Q, keys K, values V with sharpness beta."""
    W = softmax_rows(Q @ K.T, beta)
    return W, W @ V


def rod_example(x=(1.0, 1.0, 5.0, 1.0), angles_deg=(0, 30, 60, 90), beta=4.0):
    """Position-only attention and content-aware attention on the rod. Returns a dict of arrays."""
    x = np.asarray(x, float)
    theta = np.deg2rad(angles_deg)
    pos = np.stack([np.cos(theta), np.sin(theta)], 1)
    W1, y1 = attention(pos, pos, x, beta)
    K = np.concatenate([pos, x[:, None] / x.max()], 1)
    Q = np.concatenate([pos, 4.0 * (x[:, None] / x.max() - 0.6)], 1)
    W2, y2 = attention(Q, K, x, beta)
    return dict(scores=pos @ pos.T, W_pos=W1, y_pos=y1, W_content=W2, y_content=y2)


def main():
    np.set_printoptions(precision=3, suppress=True)
    r = rod_example()
    print("scores for point 1:", r["scores"][0])
    print("weights for point 1:", r["W_pos"][0], " -> new value", round(r["y_pos"][0], 2))
    print("all new values:", r["y_pos"], "(hot spot smeared to", round(r["y_pos"][2], 2), ")")
    print("content-aware weights for point 1:", r["W_content"][0], " -> new value", round(r["y_content"][0], 2))
    print("content-aware weights for point 3:", r["W_content"][2], " -> new value", round(r["y_content"][2], 2))
    print("all new values:", r["y_content"], "(noise averaged, hot spot kept)")


if __name__ == "__main__":
    main()
