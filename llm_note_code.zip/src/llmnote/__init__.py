"""llmnote: runnable companions to the note *Large Language Models: from Pen-and-Paper to Physics*.

Modules: bigram, bpe, attention_by_hand, tiny_gpt, lora_minimal, rag_minimal, solve_equations, integrate_demo.
Each has a `main()` and is exposed as a console script `llmnote-<name>`.
"""
__version__ = "0.1.0"
