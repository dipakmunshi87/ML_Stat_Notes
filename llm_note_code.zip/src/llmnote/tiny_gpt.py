"""A complete GPT-style language model in ~80 lines: tokenise -> embed -> attention -> MLP -> next-token loss ->
train -> generate. Character level; trains on a CPU in about a minute (note, Chapters 5-6).
CLI: llmnote-tiny-gpt [--steps 600] [--device cpu|cuda|mps]"""
import argparse
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

TEXT = (
    """
the heat equation describes how temperature spreads through a bar over time.
the black scholes equation for an option price is the heat equation in disguise:
substitute log price for position and time to expiry for time, and the kink of the payoff
diffuses away exactly as a spike of heat spreads into a gaussian. the diffusion constant is
half the variance rate. this is why option prices are smooth even though payoffs are not.
"""
    * 40
)


class Attention(nn.Module):
    """Causal multi-head self-attention."""

    def __init__(s, d, H, T):
        super().__init__()
        s.d, s.H = d, H
        s.qkv = nn.Linear(d, 3 * d)
        s.out = nn.Linear(d, d)
        s.register_buffer("mask", torch.tril(torch.ones(T, T)))

    def forward(s, x):
        B, N, _ = x.shape
        q, k, v = s.qkv(x).split(s.d, dim=2)
        q, k, v = (t.view(B, N, s.H, s.d // s.H).transpose(1, 2) for t in (q, k, v))
        att = (q @ k.transpose(-2, -1)) / math.sqrt(s.d // s.H)
        att = att.masked_fill(s.mask[:N, :N] == 0, float("-inf"))
        att = F.softmax(att, dim=-1)
        return s.out((att @ v).transpose(1, 2).reshape(B, N, s.d))


class Block(nn.Module):
    def __init__(s, d, H, T):
        super().__init__()
        s.ln1, s.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        s.attn = Attention(d, H, T)
        s.mlp = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))

    def forward(s, x):
        x = x + s.attn(s.ln1(x))
        return x + s.mlp(s.ln2(x))


class GPT(nn.Module):
    def __init__(s, V, T=64, d=64, H=4, L=2):
        super().__init__()
        s.T = T
        s.tok_emb, s.pos_emb = nn.Embedding(V, d), nn.Embedding(T, d)
        s.blocks = nn.Sequential(*[Block(d, H, T) for _ in range(L)])
        s.ln, s.head = nn.LayerNorm(d), nn.Linear(d, V)

    def forward(s, idx):
        B, N = idx.shape
        x = s.tok_emb(idx) + s.pos_emb(torch.arange(N, device=idx.device))
        return s.head(s.ln(s.blocks(x)))


def make_data(text=TEXT):
    chars = sorted(set(text))
    stoi = {c: i for i, c in enumerate(chars)}
    itos = {i: c for c, i in stoi.items()}
    return torch.tensor([stoi[c] for c in text]), stoi, itos


def train(steps=600, device="cpu", seed=0, lr=3e-3, batch=32, log_every=100, text=TEXT):
    """Train a tiny GPT on `text`; returns (model, losses, stoi, itos)."""
    torch.manual_seed(seed)
    data, stoi, itos = make_data(text)
    model = GPT(len(stoi)).to(device)
    T = model.T
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    losses = []
    for step in range(steps):
        ix = torch.randint(0, len(data) - T - 1, (batch,))
        x = torch.stack([data[i : i + T] for i in ix]).to(device)
        y = torch.stack([data[i + 1 : i + T + 1] for i in ix]).to(device)
        loss = F.cross_entropy(model(x).view(-1, len(stoi)), y.view(-1))
        opt.zero_grad()
        loss.backward()
        opt.step()
        losses.append(loss.item())
        if log_every and step % log_every == 0:
            print(f"step {step:4d}  loss {loss.item():.3f}  (random guess = {math.log(len(stoi)):.3f})")
    return model, losses, stoi, itos


@torch.no_grad()
def generate(model, stoi, itos, prompt, n=200, device="cpu"):
    idx = torch.tensor([[stoi[c] for c in prompt]], device=device)
    for _ in range(n):
        logits = model(idx[:, -model.T :])[:, -1, :]
        idx = torch.cat([idx, torch.multinomial(F.softmax(logits, -1), 1)], 1)
    return "".join(itos[i] for i in idx[0].tolist())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=600)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = ap.parse_args()
    model, losses, stoi, itos = train(a.steps, a.device)
    print(f"parameters: {sum(p.numel() for p in model.parameters())/1e3:.0f} k, vocab {len(stoi)}")
    print("\n" + generate(model, stoi, itos, "the black scholes equation", device=a.device))


if __name__ == "__main__":
    main()
