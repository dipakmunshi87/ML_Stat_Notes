"""A complete bigram language model: count, normalise, generate, score (note, Chapter 1)."""
import math

import numpy as np

SENTS = ["the cat sat on the mat", "the dog sat on the log", "the cat saw the dog"]


def fit(sents=SENTS):
    """Return (vocab, P) where P[i, j] = P(vocab[j] | vocab[i]) estimated by counting."""
    toks = [["<s>"] + s.split() + ["</s>"] for s in sents]
    vocab = sorted({w for t in toks for w in t})
    ix = {w: i for i, w in enumerate(vocab)}
    C = np.zeros((len(vocab), len(vocab)))
    for t in toks:
        for a, b in zip(t[:-1], t[1:]):
            C[ix[a], ix[b]] += 1
    P = C / np.maximum(C.sum(1, keepdims=True), 1)
    return vocab, P


def generate(vocab, P, seed=1, max_len=20):
    """Sample a sentence from the bigram table (argmax would loop on this corpus)."""
    rng = np.random.default_rng(seed)
    ix = {w: i for i, w in enumerate(vocab)}
    w, out = "<s>", []
    while w != "</s>" and len(out) < max_len:
        w = rng.choice(vocab, p=P[ix[w]])
        out.append(w)
    return " ".join(x for x in out if x != "</s>")


def score(vocab, P, sentence):
    """Log-likelihood, cross-entropy per token and perplexity of a sentence."""
    ix = {w: i for i, w in enumerate(vocab)}
    t = ["<s>"] + sentence.split() + ["</s>"]
    logp = [math.log(P[ix[a], ix[b]] + 1e-12) for a, b in zip(t[:-1], t[1:])]
    ce = -sum(logp) / len(logp)
    return sum(logp), ce, math.exp(ce)


def main():
    vocab, P = fit()
    ix = {w: i for i, w in enumerate(vocab)}
    print("P(cat|the) =", round(P[ix["the"], ix["cat"]], 3), " P(on|sat) =", P[ix["sat"], ix["on"]])
    print("sample:", generate(vocab, P))
    ll, ce, ppl = score(vocab, P, "the dog sat on the mat")
    print(f"log-likelihood {ll:.3f}  cross-entropy {ce:.3f} nats/token  perplexity {ppl:.2f}")


if __name__ == "__main__":
    main()
